from dataclasses import dataclass
from fastapi import Depends, HTTPException, Request
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.config import settings
from app.database import get_db

@dataclass
class CurrentUser:
    username: str
    display_name: str
    role: str

def get_current_user(request: Request, db: Session = Depends(get_db)) -> CurrentUser:
    # A identidade deve ser injectada apenas por um proxy/IIS confiável.
    username = request.headers.get("REMOTE_USER") or request.scope.get("server_user")
    if not username and settings.dev_auth_enabled:
        username = settings.dev_user
    if not username:
        raise HTTPException(401, "Utilizador não identificado. Configure Windows Authentication/SSO no servidor.")
    username = username.strip().lower()
    row = db.execute(text("""
        SELECT windows_username, display_name, role, is_active
        FROM dbo.app_users WHERE LOWER(windows_username)=:username
    """), {"username": username}).mappings().first()
    if not row or not row["is_active"]:
        raise HTTPException(403, "Utilizador sem acesso activo à aplicação.")
    return CurrentUser(row["windows_username"], row["display_name"], row["role"])

def require_roles(*roles):
    def checker(user: CurrentUser = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Não tem permissões para esta operação.")
        return user
    return checker
