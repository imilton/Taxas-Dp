(() => {
const $ = (s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const modal=$("#editModal"), form=$("#proposalForm"), msg=$("#formMessage"), summary=$("#changeSummary"); let current=null;
const fmt=n=>`${Number(n).toFixed(4)}%`;
function notice(text,type=""){msg.textContent=text;msg.className=`form-message ${type}`;}
function parsed(el){const s=el.value.trim().replace(",",".");if(!s)return null;if(!/^\d{1,3}(\.\d{1,4})?$/.test(s))return NaN;return Number(s);}
function validate(){
 const a=$("#minRate"),b=$("#maxRate"),min=parsed(a),max=parsed(b);a.classList.remove("invalid");b.classList.remove("invalid");
 if(min===null||max===null){if(min===null)a.classList.add("invalid");if(max===null)b.classList.add("invalid");return {ok:false,error:"Preencha as duas taxas."};}
 if(!Number.isFinite(min)||!Number.isFinite(max)){if(!Number.isFinite(min))a.classList.add("invalid");if(!Number.isFinite(max))b.classList.add("invalid");return {ok:false,error:"Use números válidos com até 4 casas decimais."};}
 if(min<0||max<0||min>999.9999||max>999.9999)return {ok:false,error:"As taxas devem estar entre 0 e 999,9999%."};
 if(min>max){a.classList.add("invalid");b.classList.add("invalid");return {ok:false,error:"A taxa mínima não pode ser superior à máxima."};}
 return {ok:true,min,max};
}
function updateSummary(){if(!current)return;const v=validate();if(!v.ok){summary.hidden=true;if($("#minRate").value||$("#maxRate").value)notice(v.error,"error");return;}
 notice("");summary.hidden=false;summary.innerHTML=`<strong>Resumo da proposta</strong><br>Mínima: ${fmt(current.min)} → <strong>${fmt(v.min)}</strong><br>Máxima: ${fmt(current.max)} → <strong>${fmt(v.max)}</strong>`;}
function open(button){current={id:Number(button.dataset.id),code:button.dataset.code,name:button.dataset.name,min:Number(button.dataset.min),max:Number(button.dataset.max)};
 $("#productId").value=current.id;$("#modalProductName").textContent=current.name;$("#modalProductCode").textContent=current.code;$("#currentMin").textContent=fmt(current.min);$("#currentMax").textContent=fmt(current.max);
 $("#minRate").value=current.min.toFixed(4);$("#maxRate").value=current.max.toFixed(4);$("#proposalComment").value="";notice("");summary.hidden=true;modal.classList.add("open");modal.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";updateSummary();}
function close(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true");document.body.style.overflow="";}
$$("[data-edit-product]").forEach(b=>b.addEventListener("click",()=>open(b)));$$("[data-close-modal]").forEach(b=>b.addEventListener("click",close));
modal?.addEventListener("click",e=>{if(e.target===modal)close();});document.addEventListener("keydown",e=>{if(e.key==="Escape"&&modal?.classList.contains("open"))close();});
["#minRate","#maxRate"].forEach(s=>$(s)?.addEventListener("input",updateSummary));
form?.addEventListener("submit",async e=>{e.preventDefault();const v=validate();if(!v.ok)return notice(v.error,"error");if(v.min===current.min&&v.max===current.max)return notice("Altere pelo menos uma taxa antes de submeter.","error");
 const btn=$("#submitProposal");btn.disabled=true;btn.textContent="A submeter…";
 try{const res=await fetch("/api/propostas",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({product_id:current.id,min_rate:v.min.toFixed(4),max_rate:v.max.toFixed(4),comment:$("#proposalComment").value.trim()||null})});
 const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.detail||"Não foi possível submeter a proposta.");notice(`Proposta #${data.proposal_id} submetida. As taxas oficiais não foram alteradas.`,"success");setTimeout(()=>location.reload(),1200);
 }catch(err){notice(err.message,"error");btn.disabled=false;btn.textContent="Submeter para aprovação →";}});
function search(inputId,tableId){const input=$(inputId),table=$(tableId);if(!input||!table)return;input.addEventListener("input",()=>{const q=input.value.trim().toLowerCase();$$("tbody tr",table).forEach(r=>r.hidden=!!q&&!(r.dataset.search||r.textContent.toLowerCase()).includes(q));});}
search("#productSearch","#productsTable");search("#historySearch","#historyTable");
$$("[data-decision]").forEach(btn=>btn.addEventListener("click",async()=>{const action=btn.dataset.decision,id=btn.dataset.id;let comment="";
 if(action==="reject"){comment=prompt("Indique o motivo da rejeição (obrigatório):")||"";if(!comment.trim())return;}else if(!confirm("Confirma a aprovação? As taxas oficiais serão actualizadas."))return;
 btn.disabled=true;try{const res=await fetch(`/api/propostas/${id}/${action==="approve"?"aprovar":"rejeitar"}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({comment:comment.trim()||null})});
 const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.detail||"Não foi possível registar a decisão.");alert(data.message);location.reload();}catch(err){alert(err.message);btn.disabled=false;}}));
})();
