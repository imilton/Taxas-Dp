from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.config import settings
from app.database import get_db
from app.schemas import ProposalCreate, DecisionBody
from app.security import CurrentUser, get_current_user, require_roles

ROOT = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(ROOT / "templates"))
app = FastAPI(title=settings.app_name)
app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")

def list_products(db):
    return db.execute(text("""
        SELECT p.product_id,p.product_code,p.product_name,r.min_rate,r.max_rate,r.updated_at,r.updated_by,
        (SELECT COUNT(*) FROM dbo.dp_rate_proposals q WHERE q.product_id=p.product_id AND q.status=N'Pending') pending_count
        FROM dbo.dp_products p LEFT JOIN dbo.dp_rates r ON r.product_id=p.product_id
        WHERE p.is_active=1 ORDER BY p.product_code
    """)).mappings().all()

@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse("/produtos")

@app.get("/produtos", response_class=HTMLResponse, include_in_schema=False)
def products_page(request: Request, user: CurrentUser=Depends(get_current_user), db: Session=Depends(get_db)):
    return templates.TemplateResponse(request=request, name="produtos.html", context={"user":user,"products":list_products(db)})

@app.get("/historico", response_class=HTMLResponse, include_in_schema=False)
def history_page(request: Request, user: CurrentUser=Depends(get_current_user), db: Session=Depends(get_db)):
    pending = []
    if user.role in ("Approver","Admin"):
        pending = db.execute(text("""
            SELECT q.*,p.product_code,p.product_name FROM dbo.dp_rate_proposals q
            JOIN dbo.dp_products p ON p.product_id=q.product_id WHERE q.status=N'Pending'
            ORDER BY q.submitted_at
        """)).mappings().all()
    history = db.execute(text("""
        SELECT a.*,p.product_code,p.product_name FROM dbo.dp_rate_audit a
        JOIN dbo.dp_products p ON p.product_id=a.product_id ORDER BY a.action_at DESC
    """)).mappings().all()
    return templates.TemplateResponse(request=request, name="historico.html", context={"user":user,"pending":pending,"history":history})

@app.get("/api/produtos")
def api_products(user: CurrentUser=Depends(get_current_user), db: Session=Depends(get_db)):
    return [{"product_id":p["product_id"],"product_code":p["product_code"],"product_name":p["product_name"],
             "min_rate":str(p["min_rate"]) if p["min_rate"] is not None else None,
             "max_rate":str(p["max_rate"]) if p["max_rate"] is not None else None,
             "pending_count":p["pending_count"]} for p in list_products(db)]

@app.post("/api/propostas", status_code=201)
def create_proposal(payload: ProposalCreate, user: CurrentUser=Depends(require_roles("Editor","Admin")), db: Session=Depends(get_db)):
    with db.begin_nested():
        product = db.execute(text("""
            SELECT p.product_id,p.is_active,r.min_rate,r.max_rate FROM dbo.dp_products p WITH (UPDLOCK,HOLDLOCK)
            LEFT JOIN dbo.dp_rates r ON r.product_id=p.product_id WHERE p.product_id=:pid
        """), {"pid":payload.product_id}).mappings().first()
        if not product or not product["is_active"]:
            raise HTTPException(404,"Produto não encontrado ou inactivo.")
        if product["min_rate"] is None:
            raise HTTPException(409,"O produto ainda não tem taxas iniciais configuradas.")
        pending = db.execute(text("SELECT COUNT(*) FROM dbo.dp_rate_proposals WHERE product_id=:pid AND status=N'Pending'"), {"pid":payload.product_id}).scalar_one()
        if pending:
            raise HTTPException(409,"Já existe uma proposta pendente para este produto.")
        result = db.execute(text("""
            INSERT INTO dbo.dp_rate_proposals(product_id,old_min_rate,old_max_rate,proposed_min_rate,proposed_max_rate,submitted_by)
            OUTPUT INSERTED.proposal_id
            VALUES(:pid,:omin,:omax,:nmin,:nmax,:actor)
        """), {"pid":payload.product_id,"omin":product["min_rate"],"omax":product["max_rate"],"nmin":payload.min_rate,"nmax":payload.max_rate,"actor":user.username})
        proposal_id = result.scalar_one()
        db.execute(text("""
            INSERT INTO dbo.dp_rate_audit(proposal_id,product_id,action,old_min_rate,old_max_rate,new_min_rate,new_max_rate,actor,comment)
            VALUES(:proposal,:pid,N'Submitted',:omin,:omax,:nmin,:nmax,:actor,:comment)
        """), {"proposal":proposal_id,"pid":payload.product_id,"omin":product["min_rate"],"omax":product["max_rate"],"nmin":payload.min_rate,"nmax":payload.max_rate,"actor":user.username,"comment":payload.comment})
    db.commit()
    return {"message":"Proposta submetida para aprovação.","proposal_id":proposal_id,"status":"Pending"}

def decide(proposal_id, approved, comment, user, db):
    with db.begin_nested():
        p = db.execute(text("""
            SELECT q.*,d.is_active FROM dbo.dp_rate_proposals q WITH (UPDLOCK,HOLDLOCK)
            JOIN dbo.dp_products d ON d.product_id=q.product_id WHERE q.proposal_id=:id
        """), {"id":proposal_id}).mappings().first()
        if not p: raise HTTPException(404,"Proposta não encontrada.")
        if p["status"] != "Pending": raise HTTPException(409,"Esta proposta já foi decidida.")
        if p["submitted_by"].strip().lower() == user.username.strip().lower():
            raise HTTPException(403,"Não é permitido decidir a própria proposta.")
        if approved:
            if not p["is_active"]: raise HTTPException(409,"O produto está inactivo.")
            current = db.execute(text("SELECT min_rate,max_rate FROM dbo.dp_rates WITH (UPDLOCK,HOLDLOCK) WHERE product_id=:pid"), {"pid":p["product_id"]}).mappings().first()
            if not current or current["min_rate"] != p["old_min_rate"] or current["max_rate"] != p["old_max_rate"]:
                raise HTTPException(409,"As taxas actuais diferem das taxas de referência. Submeta uma nova proposta.")
            db.execute(text("UPDATE dbo.dp_rates SET min_rate=:mn,max_rate=:mx,updated_at=SYSUTCDATETIME(),updated_by=:actor WHERE product_id=:pid"),
                       {"mn":p["proposed_min_rate"],"mx":p["proposed_max_rate"],"actor":user.username,"pid":p["product_id"]})
            status, action = "Approved","Approved"
        else:
            status, action = "Rejected","Rejected"
        db.execute(text("UPDATE dbo.dp_rate_proposals SET status=:s,decided_by=:actor,decided_at=SYSUTCDATETIME(),decision_comment=:comment WHERE proposal_id=:id"),
                   {"s":status,"actor":user.username,"comment":comment,"id":proposal_id})
        db.execute(text("""
            INSERT INTO dbo.dp_rate_audit(proposal_id,product_id,action,old_min_rate,old_max_rate,new_min_rate,new_max_rate,actor,comment)
            VALUES(:proposal,:pid,:action,:omin,:omax,:nmin,:nmax,:actor,:comment)
        """), {"proposal":proposal_id,"pid":p["product_id"],"action":action,"omin":p["old_min_rate"],"omax":p["old_max_rate"],"nmin":p["proposed_min_rate"],"nmax":p["proposed_max_rate"],"actor":user.username,"comment":comment})
    db.commit()
    return {"message":f"Proposta {status.lower()} com sucesso.","status":status}

@app.post("/api/propostas/{proposal_id}/aprovar")
def approve(proposal_id:int, payload:DecisionBody, user:CurrentUser=Depends(require_roles("Approver","Admin")), db:Session=Depends(get_db)):
    return decide(proposal_id,True,payload.comment,user,db)

@app.post("/api/propostas/{proposal_id}/rejeitar")
def reject(proposal_id:int, payload:DecisionBody, user:CurrentUser=Depends(require_roles("Approver","Admin")), db:Session=Depends(get_db)):
    if not payload.comment or not payload.comment.strip(): raise HTTPException(422,"Indique o motivo da rejeição.")
    return decide(proposal_id,False,payload.comment.strip(),user,db)
