from decimal import Decimal
from pydantic import BaseModel, Field, model_validator

class ProposalCreate(BaseModel):
    product_id: int = Field(gt=0)
    min_rate: Decimal = Field(ge=0, le=999.9999, max_digits=7, decimal_places=4)
    max_rate: Decimal = Field(ge=0, le=999.9999, max_digits=7, decimal_places=4)
    comment: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def validate_rates(self):
        if self.min_rate > self.max_rate:
            raise ValueError("A taxa mínima não pode ser superior à máxima.")
        return self

class DecisionBody(BaseModel):
    comment: str | None = Field(default=None, max_length=1000)
