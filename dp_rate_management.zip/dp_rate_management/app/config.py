from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "DP Rate Management"
    database_url: str = "mssql+pyodbc://@localhost/DP_Rate_Management?driver=ODBC+Driver+18+for+SQL+Server&trusted_connection=yes&TrustServerCertificate=yes"
    dev_auth_enabled: bool = False
    dev_user: str = r"DOMINIO\\utilizador"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
