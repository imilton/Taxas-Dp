IF DB_ID(N'DP_Rate_Management') IS NULL CREATE DATABASE DP_Rate_Management;
GO
USE DP_Rate_Management;
GO
CREATE TABLE dbo.app_users (
 user_id INT IDENTITY PRIMARY KEY,
 windows_username NVARCHAR(256) NOT NULL UNIQUE,
 display_name NVARCHAR(200) NOT NULL,
 role NVARCHAR(20) NOT NULL CHECK (role IN (N'Editor',N'Approver',N'Admin')),
 is_active BIT NOT NULL DEFAULT 1,
 created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE dbo.dp_products (
 product_id INT IDENTITY PRIMARY KEY,
 product_code NVARCHAR(40) NOT NULL UNIQUE,
 product_name NVARCHAR(200) NOT NULL,
 is_active BIT NOT NULL DEFAULT 1,
 created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE dbo.dp_rates (
 rate_id INT IDENTITY PRIMARY KEY,
 product_id INT NOT NULL UNIQUE REFERENCES dbo.dp_products(product_id),
 min_rate DECIMAL(7,4) NOT NULL CHECK (min_rate >= 0),
 max_rate DECIMAL(7,4) NOT NULL CHECK (max_rate >= 0),
 updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 updated_by NVARCHAR(256) NOT NULL,
 row_version ROWVERSION,
 CHECK (min_rate <= max_rate)
);
GO
CREATE TABLE dbo.dp_rate_proposals (
 proposal_id INT IDENTITY PRIMARY KEY,
 product_id INT NOT NULL REFERENCES dbo.dp_products(product_id),
 old_min_rate DECIMAL(7,4) NOT NULL,
 old_max_rate DECIMAL(7,4) NOT NULL,
 proposed_min_rate DECIMAL(7,4) NOT NULL,
 proposed_max_rate DECIMAL(7,4) NOT NULL,
 status NVARCHAR(20) NOT NULL DEFAULT N'Pending' CHECK (status IN (N'Pending',N'Approved',N'Rejected')),
 submitted_by NVARCHAR(256) NOT NULL,
 submitted_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 decided_by NVARCHAR(256) NULL,
 decided_at DATETIME2(3) NULL,
 decision_comment NVARCHAR(1000) NULL,
 CHECK (old_min_rate >= 0 AND old_max_rate >= old_min_rate),
 CHECK (proposed_min_rate >= 0 AND proposed_max_rate >= proposed_min_rate)
);
GO
CREATE INDEX IX_proposals_status_submitted ON dbo.dp_rate_proposals(status, submitted_at DESC);
GO
CREATE TABLE dbo.dp_rate_audit (
 audit_id BIGINT IDENTITY PRIMARY KEY,
 proposal_id INT NOT NULL REFERENCES dbo.dp_rate_proposals(proposal_id),
 product_id INT NOT NULL REFERENCES dbo.dp_products(product_id),
 action NVARCHAR(20) NOT NULL CHECK (action IN (N'Submitted',N'Approved',N'Rejected')),
 old_min_rate DECIMAL(7,4) NOT NULL,
 old_max_rate DECIMAL(7,4) NOT NULL,
 new_min_rate DECIMAL(7,4) NOT NULL,
 new_max_rate DECIMAL(7,4) NOT NULL,
 actor NVARCHAR(256) NOT NULL,
 action_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 comment NVARCHAR(1000) NULL
);
GO
CREATE INDEX IX_audit_action_at ON dbo.dp_rate_audit(action_at DESC);
GO
