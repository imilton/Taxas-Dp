# DP Rate Management

Starter para gestão de taxas de Depósitos a Prazo com FastAPI, Jinja2, HTML/CSS/JavaScript e SQL Server.

## Instalação
1. Execute `sql/schema.sql` no SQL Server.
2. Instale o Microsoft ODBC Driver 18 for SQL Server.
3. Em PowerShell:
   ```powershell
   py -3.13 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   Copy-Item .env.example .env
   uvicorn app.main:app --reload
   ```
4. Configure `DATABASE_URL` no `.env`. Exemplo de autenticação integrada:
   `mssql+pyodbc://@localhost/DP_Rate_Management?driver=ODBC+Driver+18+for+SQL+Server&trusted_connection=yes&TrustServerCertificate=yes`
5. Insira utilizadores autorizados em `dbo.app_users` e produtos/taxas iniciais (exemplos abaixo).

## Windows Authentication / SSO
Em produção, publique atrás de IIS com Windows Authentication activada e Anonymous Authentication desactivada. A aplicação precisa de receber a identidade autenticada por um mecanismo confiável e validá-la em `dbo.app_users`. A forma exacta de propagar a identidade para ASGI depende da configuração IIS/proxy; não confie em cabeçalhos que o cliente possa forjar. O modo de desenvolvimento é desactivado por defeito.

Para desenvolvimento local isolado, `DEV_AUTH_ENABLED=true` usa `DEV_USER`; nunca active este bypass em produção.

## Dados de demonstração
```sql
INSERT INTO dbo.app_users (windows_username, display_name, role, is_active)
VALUES (N'dominio\\editor', N'Editor de Exemplo', N'Editor', 1),
       (N'dominio\\aprovador', N'Aprovador de Exemplo', N'Approver', 1),
       (N'dominio\\admin', N'Administrador', N'Admin', 1);

INSERT INTO dbo.dp_products (product_code, product_name, is_active)
VALUES (N'DP001', N'Depósito a Prazo - 90 dias', 1),
       (N'DP002', N'Depósito a Prazo - 180 dias', 1);

INSERT INTO dbo.dp_rates (product_id, min_rate, max_rate, updated_by)
SELECT product_id, 5.0000, 9.0000, N'seed' FROM dbo.dp_products WHERE product_code=N'DP001';
INSERT INTO dbo.dp_rates (product_id, min_rate, max_rate, updated_by)
SELECT product_id, 5.2500, 9.2500, N'seed' FROM dbo.dp_products WHERE product_code=N'DP002';
```

Perfis: `Editor`, `Approver`, `Admin`. A versão inicial administra perfis directamente na base de dados, não pela interface.

## Endpoints
- `GET /api/produtos`
- `POST /api/propostas`
- `POST /api/propostas/{id}/aprovar`
- `POST /api/propostas/{id}/rejeitar`
- Páginas: `/produtos` e `/historico`

Antes de produção: configurar TLS válido, logging, backups, protecção CSRF quando aplicável, gestão de sessões e validar SSO com a equipa de infraestrutura/segurança.
