import os
import sys
import tempfile
from pathlib import Path

# BD temporária isolada, definida ANTES de importar a app
_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def _login(client, user):
    client.post("/api/logout")
    r = client.post("/api/login", json={"username": user, "password": f"{user}123"})
    assert r.status_code == 200, r.text
    return r.json()


def test_auth_required(client):
    client.post("/api/logout")
    assert client.get("/api/produtos").status_code == 401
    assert client.get("/", follow_redirects=False).status_code == 307
    assert client.post("/api/login", json={"username": "operador", "password": "errada"}).status_code == 401


def test_full_flow(client):
    _login(client, "operador")
    prods = client.get("/api/produtos").json()
    p = prods[0]
    assert p["pending"] is None

    # validações
    bad = lambda **kw: client.post(f"/api/produtos/{p['id']}/alteracoes", json={"justification": "teste", **kw})
    assert bad(min_rate=10, max_rate=5).status_code == 422          # min > max
    assert bad(min_rate=-1, max_rate=5).status_code == 422          # negativa
    assert bad(min_rate=1, max_rate=101).status_code == 422         # > 100
    assert bad(min_rate=1.123, max_rate=5).status_code == 422       # 3 casas
    assert bad(min_rate=p["min_rate"], max_rate=p["max_rate"]).status_code == 422  # sem alteração

    # pedido válido
    r = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 6.5, "max_rate": 9.75, "justification": "Revisão ALCO"})
    assert r.status_code == 201, r.text
    change = r.json()
    assert change["status"] == "PENDENTE" and change["requested_by_username"] == "operador"

    # segundo pedido para o mesmo produto → 409
    r = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 7, "max_rate": 9.75, "justification": "outro"})
    assert r.status_code == 409

    # taxas ainda NÃO mudaram
    cur = next(x for x in client.get("/api/produtos").json() if x["id"] == p["id"])
    assert cur["min_rate"] == p["min_rate"] and cur["pending"]["id"] == change["id"]

    # operador não aprova
    assert client.post(f"/api/alteracoes/{change['id']}/aprovar", json={}).status_code == 403

    # aprovador aprova
    _login(client, "aprovador")
    assert client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 1, "max_rate": 2, "justification": "xxx"}).status_code == 403
    r = client.post(f"/api/alteracoes/{change['id']}/aprovar", json={"comment": "OK"})
    assert r.status_code == 200 and r.json()["status"] == "APROVADO" and r.json()["reviewed_by"] == "Aprovador Demo"
    assert client.post(f"/api/alteracoes/{change['id']}/aprovar", json={}).status_code == 409  # já tratado

    cur = next(x for x in client.get("/api/produtos").json() if x["id"] == p["id"])
    assert (cur["min_rate"], cur["max_rate"], cur["pending"]) == (6.5, 9.75, None)

    # histórico
    h = client.get("/api/historico", params={"estado": "APROVADO"}).json()
    assert h["total"] == 1 and h["items"][0]["new_max"] == 9.75 and h["items"][0]["requested_by"] == "Operador Demo"
    assert client.get("/api/historico", params={"q": "operador"}).json()["total"] == 1
    assert client.get("/api/historico", params={"estado": "XPTO"}).status_code == 422
    csv = client.get("/api/historico.csv")
    assert csv.status_code == 200 and "Revisão ALCO" in csv.text


def test_reject_and_cancel(client):
    _login(client, "operador")
    p = client.get("/api/produtos").json()[1]
    c1 = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 7.5, "max_rate": 10, "justification": "Teste rejeição"}).json()

    _login(client, "aprovador")
    assert client.post(f"/api/alteracoes/{c1['id']}/rejeitar", json={}).status_code == 422  # motivo obrigatório
    r = client.post(f"/api/alteracoes/{c1['id']}/rejeitar", json={"comment": "Fora da política"})
    assert r.status_code == 200 and r.json()["status"] == "REJEITADO"
    cur = next(x for x in client.get("/api/produtos").json() if x["id"] == p["id"])
    assert cur["min_rate"] == p["min_rate"]  # inalterada

    # cancelar: só o autor
    _login(client, "operador")
    c2 = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 7.25, "max_rate": 10, "justification": "Teste cancelar"}).json()
    _login(client, "aprovador")
    assert client.post(f"/api/alteracoes/{c2['id']}/cancelar").status_code == 403
    _login(client, "operador")
    assert client.post(f"/api/alteracoes/{c2['id']}/cancelar").json()["status"] == "CANCELADO"
