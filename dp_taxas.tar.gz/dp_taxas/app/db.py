import os

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

# SQLite por omissão (zero configuração). Para SQL Server, definir por exemplo:
#   DATABASE_URL="mssql+pyodbc://user:pass@SERVIDOR/BD?driver=ODBC+Driver+18+for+SQL+Server&TrustServerCertificate=yes"
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./dp_taxas.db")

_connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=_connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
