import csv
import io
import logging
import os
from contextlib import asynccontextmanager
from datetime import timezone
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, aliased, selectinload
from starlette.middleware.sessions import SessionMiddleware

from .db import Base, SessionLocal, engine, get_db
from .models import (
    APROVADO,
    CANCELADO,
    PENDENTE,
    REJEITADO,
    ROLE_APROVADOR,
    ROLE_OPERADOR,
    STATUSES,
    Product,
    RateChange,
    User,
    utcnow,
)
from .schemas import DecisionIn, LoginIn, RateChangeIn
from .security import verify_password
from .seed import seed

log = logging.getLogger("dp_taxas")
BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"

SECRET_KEY = os.getenv("SECRET_KEY", "")
if not SECRET_KEY:
    SECRET_KEY = "dev-only-insecure-key-change-me"
    log.warning("SECRET_KEY não definida: a usar chave de desenvolvimento. Defina SECRET_KEY em produção.")


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed(db)
    yield


app = FastAPI(title="Gestão de Taxas de DP", lifespan=lifespan)
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    session_cookie="dp_session",
    max_age=8 * 3600,
    same_site="lax",
    https_only=os.getenv("COOKIE_SECURE") == "1",
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    msgs = [str(e.get("msg", "Pedido inválido")).removeprefix("Value error, ") for e in exc.errors()]
    return JSONResponse(status_code=422, content={"detail": "; ".join(dict.fromkeys(msgs))})


# --------------------------------------------------------------------------- auth
def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    uid = request.session.get("uid")
    user = db.get(User, uid) if uid else None
    if not user or not user.active:
        raise HTTPException(401, "Sessão inválida ou expirada.")
    return user


def require_role(role: str):
    def dep(user: User = Depends(current_user)) -> User:
        if user.role != role:
            raise HTTPException(403, f"Esta acção requer o perfil '{role}'.")
        return user

    return dep


@app.post("/api/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == body.username.strip().lower()))
    if not user or not user.active or not verify_password(body.password, user.password_hash):
        log.warning("Login falhado: %s", body.username)
        raise HTTPException(401, "Utilizador ou palavra-passe incorrectos.")
    request.session.clear()
    request.session["uid"] = user.id
    return _user_out(user)


@app.post("/api/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


@app.get("/api/me")
def me(user: User = Depends(current_user)):
    return _user_out(user)


# --------------------------------------------------------------------------- serializers
def _iso(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _user_out(u: User) -> dict:
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role}


def _product_out(p: Product) -> dict:
    return {
        "id": p.id,
        "code": p.code,
        "name": p.name,
        "min_rate": p.min_rate,
        "max_rate": p.max_rate,
        "updated_at": _iso(p.updated_at),
    }


def _change_out(c: RateChange) -> dict:
    return {
        "id": c.id,
        "product_id": c.product_id,
        "product_code": c.product.code,
        "product_name": c.product.name,
        "old_min": c.old_min,
        "old_max": c.old_max,
        "new_min": c.new_min,
        "new_max": c.new_max,
        "status": c.status,
        "justification": c.justification,
        "requested_by": c.requested_by.full_name,
        "requested_by_username": c.requested_by.username,
        "requested_at": _iso(c.requested_at),
        "reviewed_by": c.reviewed_by.full_name if c.reviewed_by else None,
        "reviewed_at": _iso(c.reviewed_at),
        "review_comment": c.review_comment,
    }


_LOAD_CHANGE = (
    selectinload(RateChange.product),
    selectinload(RateChange.requested_by),
    selectinload(RateChange.reviewed_by),
)


# --------------------------------------------------------------------------- produtos
@app.get("/api/produtos")
def list_products(user: User = Depends(current_user), db: Session = Depends(get_db)):
    products = db.scalars(select(Product).order_by(Product.code)).all()
    pending = {
        c.product_id: c
        for c in db.scalars(select(RateChange).where(RateChange.status == PENDENTE).options(*_LOAD_CHANGE))
    }
    return [
        {**_product_out(p), "pending": _change_out(pending[p.id]) if p.id in pending else None}
        for p in products
    ]


@app.post("/api/produtos/{product_id}/alteracoes", status_code=201)
def request_change(
    product_id: int,
    body: RateChangeIn,
    user: User = Depends(require_role(ROLE_OPERADOR)),
    db: Session = Depends(get_db),
):
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(404, "Produto não encontrado.")

    new_min, new_max = round(float(body.min_rate), 2), round(float(body.max_rate), 2)
    if new_min == round(product.min_rate, 2) and new_max == round(product.max_rate, 2):
        raise HTTPException(422, "As taxas indicadas são iguais às actuais.")
    if db.scalar(select(RateChange.id).where(RateChange.product_id == product_id, RateChange.status == PENDENTE)):
        raise HTTPException(409, "Já existe um pedido pendente de aprovação para este produto.")

    change = RateChange(
        product_id=product.id,
        old_min=product.min_rate,
        old_max=product.max_rate,
        new_min=new_min,
        new_max=new_max,
        justification=body.justification,
        requested_by_id=user.id,
    )
    db.add(change)
    try:
        db.commit()
    except IntegrityError:  # corrida: outro pedido pendente criado entretanto
        db.rollback()
        raise HTTPException(409, "Já existe um pedido pendente de aprovação para este produto.")
    log.info("Pedido #%s criado por %s (%s)", change.id, user.username, product.code)
    return _change_out(db.scalar(select(RateChange).where(RateChange.id == change.id).options(*_LOAD_CHANGE)))


# --------------------------------------------------------------------------- aprovação
def _get_pending(db: Session, change_id: int) -> RateChange:
    change = db.scalar(select(RateChange).where(RateChange.id == change_id).options(*_LOAD_CHANGE))
    if not change:
        raise HTTPException(404, "Pedido não encontrado.")
    if change.status != PENDENTE:
        raise HTTPException(409, f"O pedido já foi tratado (estado: {change.status.lower()}).")
    return change


@app.post("/api/alteracoes/{change_id}/aprovar")
def approve(
    change_id: int,
    body: DecisionIn,
    user: User = Depends(require_role(ROLE_APROVADOR)),
    db: Session = Depends(get_db),
):
    change = _get_pending(db, change_id)
    if change.requested_by_id == user.id:  # segregação de funções
        raise HTTPException(403, "Não pode aprovar um pedido submetido por si.")
    now = utcnow()
    product = change.product
    product.min_rate, product.max_rate, product.updated_at = change.new_min, change.new_max, now
    change.status, change.reviewed_by, change.reviewed_at, change.review_comment = APROVADO, user, now, body.comment
    db.commit()
    log.info("Pedido #%s APROVADO por %s", change.id, user.username)
    return _change_out(db.scalar(select(RateChange).where(RateChange.id == change.id).options(*_LOAD_CHANGE)))


@app.post("/api/alteracoes/{change_id}/rejeitar")
def reject(
    change_id: int,
    body: DecisionIn,
    user: User = Depends(require_role(ROLE_APROVADOR)),
    db: Session = Depends(get_db),
):
    if not body.comment or len(body.comment) < 3:
        raise HTTPException(422, "Indique o motivo da rejeição.")
    change = _get_pending(db, change_id)
    change.status, change.reviewed_by, change.reviewed_at, change.review_comment = REJEITADO, user, utcnow(), body.comment
    db.commit()
    log.info("Pedido #%s REJEITADO por %s", change.id, user.username)
    return _change_out(db.scalar(select(RateChange).where(RateChange.id == change.id).options(*_LOAD_CHANGE)))


@app.post("/api/alteracoes/{change_id}/cancelar")
def cancel(change_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    change = _get_pending(db, change_id)
    if change.requested_by_id != user.id:
        raise HTTPException(403, "Só quem submeteu o pedido o pode cancelar.")
    change.status, change.reviewed_by, change.reviewed_at, change.review_comment = CANCELADO, user, utcnow(), "Cancelado pelo autor"
    db.commit()
    return _change_out(db.scalar(select(RateChange).where(RateChange.id == change.id).options(*_LOAD_CHANGE)))


# --------------------------------------------------------------------------- histórico
Requester = aliased(User)


def _history_query(q: str | None, produto: int | None, estado: str | None):
    if estado and estado not in STATUSES:
        raise HTTPException(422, "Estado inválido.")
    conds = []
    if produto:
        conds.append(RateChange.product_id == produto)
    if estado:
        conds.append(RateChange.status == estado)
    if q and q.strip():
        like = f"%{q.strip()}%"
        conds.append(
            or_(
                Product.code.ilike(like),
                Product.name.ilike(like),
                Requester.full_name.ilike(like),
                Requester.username.ilike(like),
            )
        )

    def joined(stmt):
        return (
            stmt.join(Product, RateChange.product_id == Product.id)
            .join(Requester, RateChange.requested_by_id == Requester.id)
            .where(*conds)
        )

    return joined


@app.get("/api/historico")
def history(
    q: str | None = None,
    produto: int | None = None,
    estado: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=200),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    joined = _history_query(q, produto, estado)
    total = db.scalar(joined(select(func.count(RateChange.id)))) or 0
    rows = db.scalars(
        joined(select(RateChange))
        .options(*_LOAD_CHANGE)
        .order_by(RateChange.requested_at.desc(), RateChange.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()
    return {"total": total, "page": page, "page_size": page_size, "items": [_change_out(c) for c in rows]}


def _csv_safe(value) -> str:
    """Evita 'CSV injection' (fórmulas) quando o ficheiro é aberto no Excel."""
    s = "" if value is None else str(value)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


@app.get("/api/historico.csv")
def history_csv(
    q: str | None = None,
    produto: int | None = None,
    estado: str | None = None,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    joined = _history_query(q, produto, estado)
    rows = db.scalars(
        joined(select(RateChange)).options(*_LOAD_CHANGE).order_by(RateChange.requested_at.desc()).limit(50000)
    ).all()

    def pct(v):
        return f"{v:.2f}".replace(".", ",")

    buf = io.StringIO()
    buf.write("﻿")  # BOM para o Excel reconhecer UTF-8
    w = csv.writer(buf, delimiter=";")
    w.writerow(
        ["ID", "Código", "Produto", "Mín. anterior (%)", "Máx. anterior (%)", "Mín. nova (%)", "Máx. nova (%)",
         "Estado", "Justificação", "Pedido por", "Data do pedido (UTC)", "Decidido por", "Data da decisão (UTC)", "Comentário"]
    )
    for c in rows:
        w.writerow(
            [c.id, c.product.code, _csv_safe(c.product.name), pct(c.old_min), pct(c.old_max), pct(c.new_min), pct(c.new_max),
             c.status, _csv_safe(c.justification), _csv_safe(c.requested_by.full_name), _iso(c.requested_at),
             _csv_safe(c.reviewed_by.full_name if c.reviewed_by else ""), _iso(c.reviewed_at) or "", _csv_safe(c.review_comment)]
        )
    return Response(
        buf.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="historico_taxas_dp.csv"'},
    )


# --------------------------------------------------------------------------- páginas
def _page(name: str) -> FileResponse:
    return FileResponse(STATIC_DIR / name, headers={"Cache-Control": "no-store"})


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return Response(status_code=204)


@app.get("/login", include_in_schema=False)
def login_page(request: Request):
    if request.session.get("uid"):
        return RedirectResponse("/")
    return _page("login.html")


@app.get("/", include_in_schema=False)
def taxas_page(request: Request):
    if not request.session.get("uid"):
        return RedirectResponse("/login")
    return _page("index.html")


@app.get("/historico", include_in_schema=False)
def historico_page(request: Request):
    if not request.session.get("uid"):
        return RedirectResponse("/login")
    return _page("historico.html")
