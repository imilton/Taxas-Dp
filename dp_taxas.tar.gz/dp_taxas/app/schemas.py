from decimal import Decimal

from pydantic import BaseModel, field_validator, model_validator


class LoginIn(BaseModel):
    username: str
    password: str


class RateChangeIn(BaseModel):
    min_rate: Decimal
    max_rate: Decimal
    justification: str

    @field_validator("min_rate", "max_rate")
    @classmethod
    def _check_rate(cls, v: Decimal) -> Decimal:
        if not v.is_finite():
            raise ValueError("Taxa inválida.")
        if v < 0 or v > 100:
            raise ValueError("A taxa deve estar entre 0% e 100%.")
        if v != v.quantize(Decimal("0.01")):
            raise ValueError("A taxa admite no máximo 2 casas decimais.")
        return v

    @field_validator("justification")
    @classmethod
    def _check_justification(cls, v: str) -> str:
        v = v.strip()
        if not 3 <= len(v) <= 500:
            raise ValueError("A justificação deve ter entre 3 e 500 caracteres.")
        return v

    @model_validator(mode="after")
    def _check_order(self):
        if self.min_rate > self.max_rate:
            raise ValueError("A taxa mínima não pode ser superior à taxa máxima.")
        return self


class DecisionIn(BaseModel):
    comment: str | None = None

    @field_validator("comment")
    @classmethod
    def _clean(cls, v):
        if v is None:
            return None
        v = v.strip()
        if len(v) > 500:
            raise ValueError("O comentário não pode exceder 500 caracteres.")
        return v or None
