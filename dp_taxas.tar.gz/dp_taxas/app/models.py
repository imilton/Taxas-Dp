from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Numeric, String, Text, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base

PENDENTE = "PENDENTE"
APROVADO = "APROVADO"
REJEITADO = "REJEITADO"
CANCELADO = "CANCELADO"
STATUSES = (PENDENTE, APROVADO, REJEITADO, CANCELADO)

ROLE_OPERADOR = "operador"
ROLE_APROVADOR = "aprovador"


def utcnow() -> datetime:
    """UTC 'naive' (compatível com SQLite e SQL Server). A API devolve-o com offset."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def Rate():
    # Percentagem com 2 casas decimais (ex.: 11.75 = 11,75%)
    return Numeric(6, 2, asdecimal=False)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(20))  # operador | aprovador
    password_hash: Mapped[str] = mapped_column(String(255))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(160))
    min_rate: Mapped[float] = mapped_column(Rate())
    max_rate: Mapped[float] = mapped_column(Rate())
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class RateChange(Base):
    """Pedido de alteração de taxas (maker-checker). Também serve de histórico/auditoria."""

    __tablename__ = "rate_changes"
    __table_args__ = (
        # No máximo UM pedido pendente por produto (garantido pela BD, não só pela aplicação)
        Index(
            "uq_ratechange_one_pending",
            "product_id",
            unique=True,
            sqlite_where=text("status = 'PENDENTE'"),
            mssql_where=text("status = 'PENDENTE'"),
            postgresql_where=text("status = 'PENDENTE'"),
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)

    old_min: Mapped[float] = mapped_column(Rate())
    old_max: Mapped[float] = mapped_column(Rate())
    new_min: Mapped[float] = mapped_column(Rate())
    new_max: Mapped[float] = mapped_column(Rate())

    status: Mapped[str] = mapped_column(String(12), default=PENDENTE, index=True)
    justification: Mapped[str] = mapped_column(Text)

    requested_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    requested_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)

    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    review_comment: Mapped[str | None] = mapped_column(Text, nullable=True)

    product: Mapped[Product] = relationship()
    requested_by: Mapped[User] = relationship(foreign_keys=[requested_by_id])
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])
