"""Dados iniciais para arrancar a aplicação. Os produtos e taxas são EXEMPLOS: substitua pelos reais."""
import logging
import os

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import ROLE_APROVADOR, ROLE_OPERADOR, Product, User
from .security import hash_password

log = logging.getLogger("dp_taxas")

DEMO_PRODUCTS = [
    ("DP001", "Depósito a Prazo 30 dias", 6.00, 9.00),
    ("DP002", "Depósito a Prazo 90 dias", 7.00, 10.00),
    ("DP003", "Depósito a Prazo 180 dias", 8.00, 11.00),
    ("DP004", "Depósito a Prazo 365 dias", 9.00, 12.00),
    ("DP005", "Depósito a Prazo Renovável", 8.50, 11.50),
    ("DP006", "Depósito a Prazo em USD", 1.00, 3.00),
]


def seed(db: Session) -> None:
    if db.scalar(select(func.count(User.id))) == 0:
        op_pw = os.getenv("SEED_OPERADOR_PASSWORD", "operador123")
        ap_pw = os.getenv("SEED_APROVADOR_PASSWORD", "aprovador123")
        db.add_all(
            [
                User(username="operador", full_name="Operador Demo", role=ROLE_OPERADOR, password_hash=hash_password(op_pw)),
                User(username="aprovador", full_name="Aprovador Demo", role=ROLE_APROVADOR, password_hash=hash_password(ap_pw)),
            ]
        )
        log.warning("Utilizadores demo criados (operador / aprovador). Altere as passwords antes de ir para produção!")

    if os.getenv("SEED_DEMO_DATA", "1") == "1" and db.scalar(select(func.count(Product.id))) == 0:
        db.add_all([Product(code=c, name=n, min_rate=lo, max_rate=hi) for c, n, lo, hi in DEMO_PRODUCTS])
    db.commit()
