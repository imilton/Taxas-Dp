/* Utilitários partilhados pelas páginas */
const $ = (sel, el = document) => el.querySelector(sel);

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const pctNumber = new Intl.NumberFormat("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtPct = (n) => (n == null ? "—" : pctNumber.format(n) + "%");
const fmtPP = (n) => pctNumber.format(n) + " p.p.";
const fmtInput = (n) => Number(n).toFixed(2).replace(".", ",");

const dateFmt = new Intl.DateTimeFormat("pt-PT", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Maputo" });
const fmtDate = (iso) => (iso ? dateFmt.format(new Date(iso)) : "—");

/** Aceita "11,5", "11.5", "11,50%" → número; NaN se inválido. */
function parseRate(v) {
  const s = String(v).trim().replace("%", "").replace(",", ".");
  return /^\d{1,3}(\.\d{1,2})?$/.test(s) ? parseFloat(s) : NaN;
}

async function api(path, { method = "GET", body } = {}) {
  const res = await fetch(path, {
    method,
    credentials: "same-origin",
    headers: body !== undefined ? { "Content-Type": "application/json" } : {},
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401 && !location.pathname.startsWith("/login") && path !== "/api/login") {
    location.href = "/login";
    throw new Error("Sessão expirada.");
  }
  let data = null;
  try { data = await res.json(); } catch { /* sem corpo */ }
  if (!res.ok) throw new Error((data && typeof data.detail === "string" && data.detail) || `Erro ${res.status}`);
  return data;
}

function toast(msg, type = "ok") {
  const box = $("#toasts");
  const el = document.createElement("div");
  el.className = "toast" + (type === "err" ? " err" : "");
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

const STATUS_LABEL = { PENDENTE: "Pendente", APROVADO: "Aprovado", REJEITADO: "Rejeitado", CANCELADO: "Cancelado" };
const badge = (status) => `<span class="badge badge-${esc(status.toLowerCase())}">${esc(STATUS_LABEL[status] || status)}</span>`;

function deltaChip(oldV, newV) {
  const d = Math.round((newV - oldV) * 100) / 100;
  if (d === 0) return "";
  const up = d > 0;
  return `<span class="delta ${up ? "up" : "down"}">${up ? "▲" : "▼"} ${fmtPP(Math.abs(d))}</span>`;
}

/** 8,00% → 9,00%  ▲ 1,00 p.p. */
const rateDiff = (oldV, newV) =>
  `<span class="rate-old">${fmtPct(oldV)}</span><span class="arrow">→</span><strong>${fmtPct(newV)}</strong>${deltaChip(oldV, newV)}`;

function mountTopbar(user, active) {
  const roleLabel = { operador: "Operador", aprovador: "Aprovador" }[user.role] || user.role;
  $("#topbar").innerHTML = `
    <div class="topbar-inner">
      <a class="brand" href="/"><span class="brand-mark">%</span><span>Taxas DP</span></a>
      <nav class="nav">
        <a href="/" class="${active === "taxas" ? "active" : ""}">Taxas</a>
        <a href="/historico" class="${active === "historico" ? "active" : ""}">Histórico</a>
      </nav>
      <div class="user">
        <div class="user-meta"><strong>${esc(user.full_name)}</strong><span class="role">${esc(roleLabel)}</span></div>
        <button class="btn btn-ghost btn-sm" id="logout">Sair</button>
      </div>
    </div>`;
  $("#logout").onclick = async () => {
    await api("/api/logout", { method: "POST" }).catch(() => {});
    location.href = "/login";
  };
}

/** Diálogos: fechar com ✕/Cancelar e ao clicar no fundo. */
function wireDialog(dlg) {
  dlg.addEventListener("click", (e) => { if (e.target === dlg || e.target.closest("[data-close]")) dlg.close(); });
}
