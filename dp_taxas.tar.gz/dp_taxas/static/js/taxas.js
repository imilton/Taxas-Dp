(async () => {
  let me;
  try { me = await api("/api/me"); } catch { return; }
  mountTopbar(me, "taxas");

  const isOperator = me.role === "operador";
  const isApprover = me.role === "aprovador";
  if (isOperator) $("#subtitle").textContent = "Clique num produto para propor novas taxas. A alteração só entra em vigor depois de aprovada.";
  if (isApprover) $("#subtitle").textContent = "Reveja e aprove os pedidos pendentes. As taxas só mudam após a sua aprovação.";

  let products = [];
  const rows = $("#rows");
  const search = $("#search");
  const editDlg = $("#edit-dialog");
  const reviewDlg = $("#review-dialog");
  wireDialog(editDlg);
  wireDialog(reviewDlg);

  async function load() {
    products = await api("/api/produtos");
    renderKpis();
    renderPending();
    renderTable();
  }

  /* ─────────── KPIs ─────────── */
  function renderKpis() {
    const pending = products.filter((p) => p.pending).length;
    $("#kpis").innerHTML = `
      <div class="kpi"><div class="label">Produtos</div><div class="value">${products.length}</div></div>
      <div class="kpi ${pending ? "warn" : ""}"><div class="label">Pendentes</div><div class="value">${pending}</div></div>`;
  }

  /* ─────────── Pendentes ─────────── */
  function renderPending() {
    const list = products.filter((p) => p.pending).map((p) => p.pending);
    const card = $("#pending-card");
    card.hidden = list.length === 0;
    if (!list.length) return;
    $("#pending-sub").textContent = isApprover
      ? `${list.length} pedido(s) a aguardar a sua decisão.`
      : `${list.length} pedido(s) a aguardar aprovação.`;
    $("#pending-rows").innerHTML = list
      .map((c) => {
        let action = "";
        if (isApprover) action = `<button class="btn btn-sm btn-primary" data-review="${c.id}">Rever</button>`;
        else if (c.requested_by_username === me.username) action = `<button class="btn btn-sm btn-ghost" data-cancel="${c.id}">Cancelar pedido</button>`;
        return `<tr>
          <td><span class="code">${esc(c.product_code)}</span><div class="name" style="margin-top:4px">${esc(c.product_name)}</div>
              <div class="sub-line clamp" title="${esc(c.justification)}">${esc(c.justification)}</div></td>
          <td class="num">${rateDiff(c.old_min, c.new_min)}</td>
          <td class="num">${rateDiff(c.old_max, c.new_max)}</td>
          <td>${esc(c.requested_by)}<div class="muted small">${fmtDate(c.requested_at)}</div></td>
          <td class="actions">${action}</td></tr>`;
      })
      .join("");
  }

  /* ─────────── Tabela de produtos ─────────── */
  function renderTable() {
    const term = search.value.trim().toLowerCase();
    const list = products.filter((p) => !term || p.code.toLowerCase().includes(term) || p.name.toLowerCase().includes(term));
    if (!list.length) {
      rows.innerHTML = `<tr><td colspan="7" class="empty">Nenhum produto encontrado.</td></tr>`;
      return;
    }
    rows.innerHTML = list
      .map((p) => {
        const pend = p.pending;
        const canEdit = isOperator && !pend;
        let action = "";
        if (isOperator) {
          action = pend
            ? `<span class="muted small">Aguarda aprovação</span>`
            : `<button class="btn btn-sm btn-soft" data-edit="${p.id}">Actualizar taxas</button>`;
        }
        return `<tr data-id="${p.id}" class="${canEdit ? "clickable" : ""}">
          <td><span class="code">${esc(p.code)}</span></td>
          <td class="name">${esc(p.name)}</td>
          <td class="num">${fmtPct(p.min_rate)}${pend ? `<div class="proposed">→ ${fmtPct(pend.new_min)}</div>` : ""}</td>
          <td class="num">${fmtPct(p.max_rate)}${pend ? `<div class="proposed">→ ${fmtPct(pend.new_max)}</div>` : ""}</td>
          <td>${pend ? badge("PENDENTE") : '<span class="badge badge-ok">Em vigor</span>'}</td>
          <td class="muted nowrap">${fmtDate(p.updated_at)}</td>
          <td class="actions">${action}</td></tr>`;
      })
      .join("");
  }

  search.addEventListener("input", renderTable);

  rows.addEventListener("click", (e) => {
    const tr = e.target.closest("tr[data-id]");
    if (!tr || !isOperator) return;
    const p = products.find((x) => x.id === Number(tr.dataset.id));
    if (p && !p.pending) openEdit(p);
  });

  $("#pending-rows").addEventListener("click", async (e) => {
    const rv = e.target.closest("[data-review]");
    const cn = e.target.closest("[data-cancel]");
    if (rv) {
      const c = products.map((p) => p.pending).find((c) => c && c.id === Number(rv.dataset.review));
      if (c) openReview(c);
    } else if (cn && confirm("Cancelar este pedido de alteração?")) {
      try {
        await api(`/api/alteracoes/${cn.dataset.cancel}/cancelar`, { method: "POST" });
        toast("Pedido cancelado.");
        await load();
      } catch (ex) { toast(ex.message, "err"); await load(); }
    }
  });

  /* ─────────── Actualizar taxas (operador) ─────────── */
  let editing = null;
  const edMin = $("#ed-min"), edMax = $("#ed-max"), edJust = $("#ed-just"), edErr = $("#ed-error");

  function openEdit(p) {
    editing = p;
    $("#ed-code").textContent = p.code;
    $("#ed-name").textContent = p.name;
    $("#ed-cur-min").textContent = fmtPct(p.min_rate);
    $("#ed-cur-max").textContent = fmtPct(p.max_rate);
    edMin.value = fmtInput(p.min_rate);
    edMax.value = fmtInput(p.max_rate);
    edJust.value = "";
    edErr.hidden = true;
    updateHints();
    editDlg.showModal();
    edMin.focus();
    edMin.select();
  }

  function hint(el, cur, raw) {
    const v = parseRate(raw);
    if (Number.isNaN(v)) { el.textContent = raw.trim() ? "Valor inválido" : ""; return; }
    const d = Math.round((v - cur) * 100) / 100;
    el.textContent = d === 0 ? "Sem alteração" : `${d > 0 ? "▲ +" : "▼ −"}${fmtPP(Math.abs(d))} face à actual`;
  }
  function updateHints() {
    hint($("#ed-min-hint"), editing.min_rate, edMin.value);
    hint($("#ed-max-hint"), editing.max_rate, edMax.value);
  }
  edMin.addEventListener("input", updateHints);
  edMax.addEventListener("input", updateHints);

  $("#edit-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const min = parseRate(edMin.value), max = parseRate(edMax.value), just = edJust.value.trim();
    const fail = (m) => { edErr.textContent = m; edErr.hidden = false; };
    if (Number.isNaN(min) || Number.isNaN(max)) return fail("Indique taxas válidas (0 a 100, até 2 casas decimais).");
    if (min > 100 || max > 100) return fail("A taxa não pode exceder 100%.");
    if (min > max) return fail("A taxa mínima não pode ser superior à taxa máxima.");
    if (min === editing.min_rate && max === editing.max_rate) return fail("As taxas indicadas são iguais às actuais.");
    if (just.length < 3) return fail("Indique a justificação da alteração.");

    const btn = $("#ed-submit");
    btn.disabled = true; edErr.hidden = true;
    try {
      await api(`/api/produtos/${editing.id}/alteracoes`, { method: "POST", body: { min_rate: min, max_rate: max, justification: just } });
      editDlg.close();
      toast("Pedido submetido. Aguarda aprovação.");
    } catch (ex) {
      fail(ex.message);
    } finally {
      btn.disabled = false;
    }
    load();
  });

  /* ─────────── Rever pedido (aprovador) ─────────── */
  let reviewing = null;
  const rvComment = $("#rv-comment"), rvErr = $("#rv-error");

  function openReview(c) {
    reviewing = c;
    $("#rv-code").textContent = c.product_code;
    $("#rv-name").textContent = c.product_name;
    $("#rv-min").innerHTML = rateDiff(c.old_min, c.new_min);
    $("#rv-max").innerHTML = rateDiff(c.old_max, c.new_max);
    $("#rv-meta").innerHTML = `Submetido por <strong>${esc(c.requested_by)}</strong> · ${fmtDate(c.requested_at)}`;
    $("#rv-just").textContent = c.justification;
    rvComment.value = "";
    rvErr.hidden = true;
    const own = c.requested_by_username === me.username;
    $("#rv-approve").disabled = own;
    if (own) { rvErr.textContent = "Não pode aprovar um pedido submetido por si."; rvErr.hidden = false; }
    reviewDlg.showModal();
  }

  async function decide(kind) {
    const comment = rvComment.value.trim();
    if (kind === "rejeitar" && comment.length < 3) {
      rvErr.textContent = "Indique o motivo da rejeição.";
      rvErr.hidden = false;
      rvComment.focus();
      return;
    }
    const btns = [$("#rv-approve"), $("#rv-reject")];
    btns.forEach((b) => (b.disabled = true));
    try {
      await api(`/api/alteracoes/${reviewing.id}/${kind}`, { method: "POST", body: { comment: comment || null } });
      reviewDlg.close();
      toast(kind === "aprovar" ? "Taxas aprovadas e em vigor." : "Pedido rejeitado.");
    } catch (ex) {
      rvErr.textContent = ex.message; rvErr.hidden = false;
    } finally {
      btns.forEach((b) => (b.disabled = false));
    }
    load();
  }
  $("#rv-approve").onclick = () => decide("aprovar");
  $("#rv-reject").onclick = () => decide("rejeitar");

  await load();
})();
