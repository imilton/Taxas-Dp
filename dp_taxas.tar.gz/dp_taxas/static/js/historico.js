(async () => {
  let me;
  try { me = await api("/api/me"); } catch { return; }
  mountTopbar(me, "historico");

  const PAGE_SIZE = 25;
  const state = { page: 1 };
  const rows = $("#rows");

  // Filtro por produto
  try {
    const prods = await api("/api/produtos");
    $("#produto").insertAdjacentHTML(
      "beforeend",
      prods.map((p) => `<option value="${p.id}">${esc(p.code)} · ${esc(p.name)}</option>`).join("")
    );
  } catch { /* o filtro fica só com "Todos" */ }

  function filters() {
    const p = new URLSearchParams();
    const q = $("#q").value.trim();
    if (q) p.set("q", q);
    if ($("#produto").value) p.set("produto", $("#produto").value);
    if ($("#estado").value) p.set("estado", $("#estado").value);
    return p;
  }

  async function load() {
    const params = filters();
    $("#export").href = "/api/historico.csv" + (params.toString() ? "?" + params : "");
    params.set("page", state.page);
    params.set("page_size", PAGE_SIZE);
    try {
      const data = await api("/api/historico?" + params);
      render(data);
    } catch (ex) {
      rows.innerHTML = `<tr><td colspan="6" class="empty">${esc(ex.message)}</td></tr>`;
    }
  }

  function render({ total, page, page_size, items }) {
    $("#count").textContent = `${total} registo(s)`;
    if (!items.length) {
      rows.innerHTML = `<tr><td colspan="6" class="empty">Sem registos para os filtros seleccionados.</td></tr>`;
    } else {
      rows.innerHTML = items
        .map((c) => {
          const decision = c.reviewed_by
            ? `${esc(c.reviewed_by)}<div class="muted small">${fmtDate(c.reviewed_at)}</div>` +
              (c.review_comment ? `<div class="sub-line clamp" title="${esc(c.review_comment)}">“${esc(c.review_comment)}”</div>` : "")
            : `<span class="muted">—</span>`;
          return `<tr>
            <td class="nowrap">${fmtDate(c.requested_at)}</td>
            <td class="min-prod"><span class="code">${esc(c.product_code)}</span><div class="name" style="margin-top:4px">${esc(c.product_name)}</div>
                <div class="sub-line clamp" title="${esc(c.justification)}">${esc(c.justification)}</div></td>
            <td class="num"><div class="rate-line"><span class="rl">Mín</span>${rateDiff(c.old_min, c.new_min)}</div>
                <div class="rate-line"><span class="rl">Máx</span>${rateDiff(c.old_max, c.new_max)}</div></td>
            <td>${esc(c.requested_by)}</td>
            <td>${badge(c.status)}</td>
            <td class="min-dec">${decision}</td></tr>`;
        })
        .join("");
    }
    const from = total ? (page - 1) * page_size + 1 : 0;
    const to = Math.min(page * page_size, total);
    $("#range").textContent = total ? `A mostrar ${from}–${to} de ${total}` : "";
    $("#prev").disabled = page <= 1;
    $("#next").disabled = page * page_size >= total;
  }

  const reset = () => { state.page = 1; load(); };
  let t;
  $("#q").addEventListener("input", () => { clearTimeout(t); t = setTimeout(reset, 300); });
  $("#produto").addEventListener("change", reset);
  $("#estado").addEventListener("change", reset);
  $("#prev").onclick = () => { state.page--; load(); };
  $("#next").onclick = () => { state.page++; load(); };

  await load();
})();
