# Gestão de Taxas de DP

FastAPI + HTML/CSS/JavaScript (sem frameworks de frontend). Fluxo **maker-checker**:
o operador propõe novas taxas, o aprovador valida, e só então as taxas entram em vigor.

## Arrancar

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Abrir http://localhost:8000

Utilizadores de demonstração (criados no primeiro arranque):

| Utilizador  | Palavra-passe  | Perfil    |
|-------------|----------------|-----------|
| `operador`  | `operador123`  | Operador  |
| `aprovador` | `aprovador123` | Aprovador |

> Mude-as antes de sair do ambiente de testes: `SEED_OPERADOR_PASSWORD`, `SEED_APROVADOR_PASSWORD`.
> Os 6 produtos iniciais são **exemplos** (`app/seed.py`). Desligue-os com `SEED_DEMO_DATA=0`.

## Páginas

1. **Taxas** (`/`): lista de produtos (código, nome, taxa mínima/máxima em %).
   - *Operador*: clica no produto → altera as taxas + justificação → fica **Pendente**. Pode cancelar o seu pedido.
   - *Aprovador*: painel de pendentes → **Rever** → Aprovar ou Rejeitar (motivo obrigatório ao rejeitar).
2. **Histórico** (`/historico`): todos os pedidos (taxa anterior → nova, quem pediu, quem decidiu, quando, comentário), com pesquisa, filtros por produto/estado, paginação e **exportação CSV**.

## Regras de negócio implementadas

- Taxas entre 0% e 100%, máx. 2 casas decimais, mínima ≤ máxima (validado no browser **e** no servidor).
- Só um pedido pendente por produto (garantido por índice único na BD).
- As taxas em vigor **só mudam** na aprovação.
- Segregação de funções: quem submete não pode aprovar o próprio pedido.
- Auditoria completa: nada é apagado, cada pedido guarda taxas antigas/novas, autor, decisor e datas (UTC na BD, Africa/Maputo no ecrã).
- CSV protegido contra *formula injection* no Excel; HTML escapado no frontend.

## Configuração (variáveis de ambiente)

| Variável | Para quê |
|---|---|
| `DATABASE_URL` | Por omissão SQLite (`dp_taxas.db`). SQL Server: `mssql+pyodbc://user:pass@SERVIDOR/BD?driver=ODBC+Driver+18+for+SQL+Server&TrustServerCertificate=yes` (`pip install pyodbc`) |
| `SECRET_KEY` | **Obrigatória em produção** (assina o cookie de sessão). Ex.: `python -c "import secrets;print(secrets.token_hex(32))"` |
| `COOKIE_SECURE=1` | Cookie só por HTTPS (activar atrás de HTTPS) |

## Testes

```bash
pytest -q
```

## Estrutura

```
app/        main.py (rotas), models.py, schemas.py, security.py, seed.py, db.py
static/     login.html, index.html, historico.html, css/style.css, js/*.js
tests/      test_flow.py
```

## Para produção (não incluído)

- Autenticação corporativa (AD/LDAP/SSO) em vez de utilizadores locais; gestão de utilizadores.
- Limitação de tentativas de login e HTTPS (reverse proxy).
- Migrações com Alembic em vez de `create_all`.
- Notificação ao aprovador (email) quando há novo pedido pendente.
