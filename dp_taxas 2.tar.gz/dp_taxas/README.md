# Gestão de Taxas de DP

FastAPI + **pyodbc (T-SQL puro, sem ORM)** + HTML/CSS/JavaScript. Fluxo **maker-checker**:
o operador propõe novas taxas, o aprovador valida, e só então as taxas entram em vigor.

## Requisitos

- Python 3.10+
- **Microsoft ODBC Driver 17 ou 18 for SQL Server** na máquina onde a aplicação corre
  (Windows: instalador da Microsoft; Linux: pacote `msodbcsql18` + `unixodbc`).
- Uma base de dados SQL Server (pode ser vazia; a aplicação cria as 3 tabelas `dp_*`).

## Arrancar

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Windows (PowerShell) — autenticação Windows:
$env:DB_SERVER="SERVIDOR"; $env:DB_NAME="DPTaxas"; $env:DB_TRUSTED="1"
$env:DB_DRIVER="ODBC Driver 17 for SQL Server"        # se só tiver o 17 (por omissão usa o 18)
$env:SECRET_KEY="<valor-aleatório-longo>"

# Linux/macOS — utilizador SQL:
export DB_SERVER=SERVIDOR DB_NAME=DPTaxas DB_USER=app_dp DB_PASSWORD='***' DB_TRUST_CERT=1 SECRET_KEY=...

uvicorn app.main:app --reload     # http://localhost:8000
```

Alternativa: uma única `DB_CONNECTION_STRING="DRIVER={ODBC Driver 18 for SQL Server};SERVER=...;DATABASE=...;..."`.

No primeiro arranque são criadas as tabelas (`sql/schema.sql`) e os utilizadores de demonstração:

| Utilizador  | Palavra-passe  | Perfil    |
|-------------|----------------|-----------|
| `operador`  | `operador123`  | Operador  |
| `aprovador` | `aprovador123` | Aprovador |

> Mude-as antes de sair do ambiente de testes (`SEED_OPERADOR_PASSWORD`, `SEED_APROVADOR_PASSWORD`).
> Os 6 produtos iniciais são **exemplos** (`app/repo.py`); desligue-os com `SEED_DEMO_DATA=0`.
> Em produção o DBA pode correr `sql/schema.sql` no SSMS e arrancar com `AUTO_CREATE_SCHEMA=0`.

## Páginas

1. **Taxas** (`/`): produtos (código, nome, taxa mínima/máxima em %).
   - *Operador*: clica no produto → altera as taxas + justificação → fica **Pendente**. Pode cancelar o seu pedido.
   - *Aprovador*: painel de pendentes → **Rever** → Aprovar ou Rejeitar (motivo obrigatório ao rejeitar).
2. **Histórico** (`/historico`): todos os pedidos (taxa anterior → nova, quem pediu, quem decidiu, quando, comentário), com pesquisa (ignora maiúsculas e acentos), filtros, paginação e **exportação CSV**.

## Regras de negócio

- Taxas entre 0% e 100%, máx. 2 casas decimais, mínima ≤ máxima (browser, servidor e `CHECK` na BD).
- Só um pedido pendente por produto (índice único filtrado na BD, seguro com pedidos simultâneos).
- As taxas em vigor **só mudam** na aprovação; aprovar = 2 `UPDATE` na mesma transacção, com protecção contra dois aprovadores em simultâneo.
- Segregação de funções: quem submete não pode aprovar o próprio pedido.
- Auditoria: nada é apagado; cada pedido guarda taxas antigas/novas, autor, decisor e datas (UTC na BD, Africa/Maputo no ecrã).
- Todo o SQL é parametrizado (`?`); CSV protegido contra *formula injection*; HTML escapado no frontend.

## Variáveis de ambiente

| Variável | Para quê |
|---|---|
| `DB_CONNECTION_STRING` **ou** `DB_SERVER` + `DB_NAME` | Ligação ao SQL Server |
| `DB_USER` + `DB_PASSWORD` **ou** `DB_TRUSTED=1` | SQL login ou autenticação Windows |
| `DB_DRIVER` | Por omissão `ODBC Driver 18 for SQL Server` |
| `DB_TRUST_CERT=1` | `TrustServerCertificate=yes` (certificado interno/autoassinado) |
| `AUTO_CREATE_SCHEMA` | `1` (omissão) cria as tabelas no arranque; `0` desliga |
| `SECRET_KEY` | **Obrigatória em produção** (assina o cookie). `python -c "import secrets;print(secrets.token_hex(32))"` |
| `COOKIE_SECURE=1` | Cookie só por HTTPS |

## Testes

```bash
pytest -q                                    # rápido: SQLite via adaptador (tests/sqlite_shim.py)
TEST_DB_CONNECTION_STRING="DRIVER={...};SERVER=...;DATABASE=DPTaxas_TESTE;..." pytest -q   # contra SQL Server real
```

**Importante:** o modo por omissão valida a lógica da API e a sintaxe geral do T-SQL, mas **não substitui**
SQL Server real (collation, `OUTPUT INSERTED`, índice filtrado). Corra a 2.ª forma **uma vez** numa BD de
teste **vazia e dedicada** (os testes criam tabelas e dados de demonstração) antes de ir para produção.

## Estrutura

```
app/        main.py (rotas) · repo.py (todo o T-SQL) · db.py (pyodbc) · schemas.py · security.py
sql/        schema.sql (idempotente, lotes separados por GO)
static/     login.html, index.html, historico.html, css/style.css, js/*.js
tests/      test_flow.py, conftest.py, sqlite_shim.py
```

## Para produção (não incluído)

- Autenticação corporativa (AD/LDAP/SSO) e gestão de utilizadores.
- Limitação de tentativas de login e HTTPS (reverse proxy).
- Notificação por email ao aprovador; segundo nível de aprovação, se a política o exigir.
