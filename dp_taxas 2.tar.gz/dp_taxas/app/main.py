import csv
import io
import logging
import os
from contextlib import asynccontextmanager
from datetime import timezone
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from . import db, repo
from .repo import PENDENTE, ROLE_APROVADOR, ROLE_OPERADOR, STATUSES
from .schemas import DecisionIn, LoginIn, RateChangeIn
from .security import verify_password

log = logging.getLogger("dp_taxas")
BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"

SECRET_KEY = os.getenv("SECRET_KEY", "")
if not SECRET_KEY:
    SECRET_KEY = "dev-only-insecure-key-change-me"
    log.warning("SECRET_KEY não definida: a usar chave de desenvolvimento. Defina SECRET_KEY em produção.")


@asynccontextmanager
async def lifespan(app: FastAPI):
    conn = db.connect()  # falha logo no arranque se a BD não estiver acessível
    try:
        if os.getenv("AUTO_CREATE_SCHEMA", "1") == "1":
            db.init_schema(conn)
        repo.seed(conn)
    finally:
        conn.close()
    yield


app = FastAPI(title="Gestão de Taxas de DP", lifespan=lifespan)
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    session_cookie="dp_session",
    max_age=8 * 3600,
    same_site="lax",
    https_only=os.getenv("COOKIE_SECURE") == "1",
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    msgs = [str(e.get("msg", "Pedido inválido")).removeprefix("Value error, ") for e in exc.errors()]
    return JSONResponse(status_code=422, content={"detail": "; ".join(dict.fromkeys(msgs))})


# --------------------------------------------------------------------------- auth
def current_user(request: Request, conn=Depends(db.get_db)) -> dict:
    uid = request.session.get("uid")
    user = repo.get_user(conn, uid) if uid else None
    if not user or not user["active"]:
        raise HTTPException(401, "Sessão inválida ou expirada.")
    return user


def require_role(role: str):
    def dep(user: dict = Depends(current_user)) -> dict:
        if user["role"] != role:
            raise HTTPException(403, f"Esta acção requer o perfil '{role}'.")
        return user

    return dep


@app.post("/api/login")
def login(body: LoginIn, request: Request, conn=Depends(db.get_db)):
    user = repo.get_user_by_username(conn, body.username.strip().lower())
    if not user or not user["active"] or not verify_password(body.password, user["password_hash"]):
        log.warning("Login falhado: %s", body.username)
        raise HTTPException(401, "Utilizador ou palavra-passe incorrectos.")
    request.session.clear()
    request.session["uid"] = user["id"]
    return _user_out(user)


@app.post("/api/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


@app.get("/api/me")
def me(user: dict = Depends(current_user)):
    return _user_out(user)


# --------------------------------------------------------------------------- serializers
def _iso(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:  # a BD guarda UTC (SYSUTCDATETIME)
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _num(v):
    return None if v is None else float(v)


def _user_out(u: dict) -> dict:
    return {"id": u["id"], "username": u["username"], "full_name": u["full_name"], "role": u["role"]}


def _product_out(p: dict) -> dict:
    return {
        "id": p["id"],
        "code": p["code"],
        "name": p["name"],
        "min_rate": _num(p["min_rate"]),
        "max_rate": _num(p["max_rate"]),
        "updated_at": _iso(p["updated_at"]),
    }


def _change_out(c: dict) -> dict:
    return {
        "id": c["id"],
        "product_id": c["product_id"],
        "product_code": c["product_code"],
        "product_name": c["product_name"],
        "old_min": _num(c["old_min"]),
        "old_max": _num(c["old_max"]),
        "new_min": _num(c["new_min"]),
        "new_max": _num(c["new_max"]),
        "status": c["status"],
        "justification": c["justification"],
        "requested_by": c["requested_by"],
        "requested_by_username": c["requested_by_username"],
        "requested_at": _iso(c["requested_at"]),
        "reviewed_by": c["reviewed_by"],
        "reviewed_at": _iso(c["reviewed_at"]),
        "review_comment": c["review_comment"],
    }


# --------------------------------------------------------------------------- produtos
@app.get("/api/produtos")
def list_products(user: dict = Depends(current_user), conn=Depends(db.get_db)):
    pending = {c["product_id"]: c for c in repo.list_pending(conn)}
    return [
        {**_product_out(p), "pending": _change_out(pending[p["id"]]) if p["id"] in pending else None}
        for p in repo.list_products(conn)
    ]


@app.post("/api/produtos/{product_id}/alteracoes", status_code=201)
def request_change(
    product_id: int,
    body: RateChangeIn,
    user: dict = Depends(require_role(ROLE_OPERADOR)),
    conn=Depends(db.get_db),
):
    product = repo.get_product(conn, product_id)
    if not product:
        raise HTTPException(404, "Produto não encontrado.")
    if repo.dec(body.min_rate) == repo.dec(product["min_rate"]) and repo.dec(body.max_rate) == repo.dec(product["max_rate"]):
        raise HTTPException(422, "As taxas indicadas são iguais às actuais.")
    if repo.has_pending(conn, product_id):
        raise HTTPException(409, "Já existe um pedido pendente de aprovação para este produto.")

    new_id = repo.create_change(conn, product, body.min_rate, body.max_rate, body.justification, user["id"])
    if new_id is None:  # corrida: outro pedido pendente criado entretanto
        raise HTTPException(409, "Já existe um pedido pendente de aprovação para este produto.")
    log.info("Pedido #%s criado por %s (%s)", new_id, user["username"], product["code"])
    return _change_out(repo.get_change(conn, new_id))


# --------------------------------------------------------------------------- aprovação
def _get_pending(conn, change_id: int) -> dict:
    change = repo.get_change(conn, change_id)
    if not change:
        raise HTTPException(404, "Pedido não encontrado.")
    if change["status"] != PENDENTE:
        raise HTTPException(409, f"O pedido já foi tratado (estado: {change['status'].lower()}).")
    return change


def _already_handled():
    return HTTPException(409, "O pedido já foi tratado por outra pessoa.")


@app.post("/api/alteracoes/{change_id}/aprovar")
def approve(
    change_id: int,
    body: DecisionIn,
    user: dict = Depends(require_role(ROLE_APROVADOR)),
    conn=Depends(db.get_db),
):
    change = _get_pending(conn, change_id)
    if change["requested_by_id"] == user["id"]:  # segregação de funções
        raise HTTPException(403, "Não pode aprovar um pedido submetido por si.")
    if not repo.approve_change(conn, change, user["id"], body.comment):
        raise _already_handled()
    log.info("Pedido #%s APROVADO por %s", change_id, user["username"])
    return _change_out(repo.get_change(conn, change_id))


@app.post("/api/alteracoes/{change_id}/rejeitar")
def reject(
    change_id: int,
    body: DecisionIn,
    user: dict = Depends(require_role(ROLE_APROVADOR)),
    conn=Depends(db.get_db),
):
    if not body.comment or len(body.comment) < 3:
        raise HTTPException(422, "Indique o motivo da rejeição.")
    _get_pending(conn, change_id)
    if not repo.reject_change(conn, change_id, user["id"], body.comment):
        raise _already_handled()
    log.info("Pedido #%s REJEITADO por %s", change_id, user["username"])
    return _change_out(repo.get_change(conn, change_id))


@app.post("/api/alteracoes/{change_id}/cancelar")
def cancel(change_id: int, user: dict = Depends(current_user), conn=Depends(db.get_db)):
    change = _get_pending(conn, change_id)
    if change["requested_by_id"] != user["id"]:
        raise HTTPException(403, "Só quem submeteu o pedido o pode cancelar.")
    if not repo.cancel_change(conn, change_id, user["id"]):
        raise _already_handled()
    return _change_out(repo.get_change(conn, change_id))


# --------------------------------------------------------------------------- histórico
def _check_estado(estado: str | None):
    if estado and estado not in STATUSES:
        raise HTTPException(422, "Estado inválido.")


@app.get("/api/historico")
def history(
    q: str | None = None,
    produto: int | None = None,
    estado: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=200),
    user: dict = Depends(current_user),
    conn=Depends(db.get_db),
):
    _check_estado(estado)
    total, rows = repo.history(conn, q, produto, estado, page, page_size)
    return {"total": total, "page": page, "page_size": page_size, "items": [_change_out(c) for c in rows]}


def _csv_safe(value) -> str:
    """Evita 'CSV injection' (fórmulas) quando o ficheiro é aberto no Excel."""
    s = "" if value is None else str(value)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


@app.get("/api/historico.csv")
def history_csv(
    q: str | None = None,
    produto: int | None = None,
    estado: str | None = None,
    user: dict = Depends(current_user),
    conn=Depends(db.get_db),
):
    _check_estado(estado)
    rows = repo.history_all(conn, q, produto, estado)

    def pct(v):
        return f"{float(v):.2f}".replace(".", ",")

    buf = io.StringIO()
    buf.write("﻿")  # BOM para o Excel reconhecer UTF-8
    w = csv.writer(buf, delimiter=";")
    w.writerow(
        ["ID", "Código", "Produto", "Mín. anterior (%)", "Máx. anterior (%)", "Mín. nova (%)", "Máx. nova (%)",
         "Estado", "Justificação", "Pedido por", "Data do pedido (UTC)", "Decidido por", "Data da decisão (UTC)", "Comentário"]
    )
    for c in rows:
        w.writerow(
            [c["id"], c["product_code"], _csv_safe(c["product_name"]), pct(c["old_min"]), pct(c["old_max"]),
             pct(c["new_min"]), pct(c["new_max"]), c["status"], _csv_safe(c["justification"]),
             _csv_safe(c["requested_by"]), _iso(c["requested_at"]), _csv_safe(c["reviewed_by"] or ""),
             _iso(c["reviewed_at"]) or "", _csv_safe(c["review_comment"])]
        )
    return Response(
        buf.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="historico_taxas_dp.csv"'},
    )


# --------------------------------------------------------------------------- páginas
def _page(name: str) -> FileResponse:
    return FileResponse(STATIC_DIR / name, headers={"Cache-Control": "no-store"})


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return Response(status_code=204)


@app.get("/login", include_in_schema=False)
def login_page(request: Request):
    if request.session.get("uid"):
        return RedirectResponse("/")
    return _page("login.html")


@app.get("/", include_in_schema=False)
def taxas_page(request: Request):
    if not request.session.get("uid"):
        return RedirectResponse("/login")
    return _page("index.html")


@app.get("/historico", include_in_schema=False)
def historico_page(request: Request):
    if not request.session.get("uid"):
        return RedirectResponse("/login")
    return _page("historico.html")
