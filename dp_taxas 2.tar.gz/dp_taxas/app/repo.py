"""Acesso a dados: todo o T-SQL da aplicação vive aqui. Parâmetros sempre com '?' (nunca concatenar valores)."""
import os
from decimal import Decimal

from . import db
from .security import hash_password

PENDENTE, APROVADO, REJEITADO, CANCELADO = "PENDENTE", "APROVADO", "REJEITADO", "CANCELADO"
STATUSES = (PENDENTE, APROVADO, REJEITADO, CANCELADO)
ROLE_OPERADOR, ROLE_APROVADOR = "operador", "aprovador"

DEMO_PRODUCTS = [  # EXEMPLOS: substitua pelos produtos reais
    ("DP001", "Depósito a Prazo 30 dias", "6.00", "9.00"),
    ("DP002", "Depósito a Prazo 90 dias", "7.00", "10.00"),
    ("DP003", "Depósito a Prazo 180 dias", "8.00", "11.00"),
    ("DP004", "Depósito a Prazo 365 dias", "9.00", "12.00"),
    ("DP005", "Depósito a Prazo Renovável", "8.50", "11.50"),
    ("DP006", "Depósito a Prazo em USD", "1.00", "3.00"),
]


# ------------------------------------------------------------------ helpers
def _q(conn, sql: str, params=()):
    cur = conn.cursor()
    cur.execute(sql, params)
    return cur


def _rows(cur) -> list[dict]:
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _one(cur) -> dict | None:
    rows = _rows(cur)
    return rows[0] if rows else None


def dec(value) -> Decimal:
    """Normaliza taxas para Decimal com 2 casas (comparações exactas)."""
    return Decimal(str(value)).quantize(Decimal("0.01"))


# ------------------------------------------------------------------ utilizadores
def get_user_by_username(conn, username: str) -> dict | None:
    return _one(_q(conn, "SELECT id, username, full_name, role, password_hash, active FROM dbo.dp_users WHERE username = ?", (username,)))


def get_user(conn, user_id: int) -> dict | None:
    return _one(_q(conn, "SELECT id, username, full_name, role, password_hash, active FROM dbo.dp_users WHERE id = ?", (user_id,)))


# ------------------------------------------------------------------ produtos
def list_products(conn) -> list[dict]:
    return _rows(_q(conn, "SELECT id, code, name, min_rate, max_rate, updated_at FROM dbo.dp_products ORDER BY code"))


def get_product(conn, product_id: int) -> dict | None:
    return _one(_q(conn, "SELECT id, code, name, min_rate, max_rate, updated_at FROM dbo.dp_products WHERE id = ?", (product_id,)))


# ------------------------------------------------------------------ pedidos de alteração
_CHANGE_COLS = """
    c.id, c.product_id, p.code AS product_code, p.name AS product_name,
    c.old_min, c.old_max, c.new_min, c.new_max, c.status, c.justification,
    c.requested_by_id, rq.full_name AS requested_by, rq.username AS requested_by_username, c.requested_at,
    rv.full_name AS reviewed_by, c.reviewed_at, c.review_comment"""

_CHANGE_FROM = """
    FROM dbo.dp_rate_changes c
    JOIN dbo.dp_products p ON p.id = c.product_id
    JOIN dbo.dp_users rq ON rq.id = c.requested_by_id
    LEFT JOIN dbo.dp_users rv ON rv.id = c.reviewed_by_id"""


def get_change(conn, change_id: int) -> dict | None:
    return _one(_q(conn, f"SELECT {_CHANGE_COLS} {_CHANGE_FROM} WHERE c.id = ?", (change_id,)))


def list_pending(conn) -> list[dict]:
    return _rows(_q(conn, f"SELECT {_CHANGE_COLS} {_CHANGE_FROM} WHERE c.status = 'PENDENTE'"))


def has_pending(conn, product_id: int) -> bool:
    return _q(conn, "SELECT 1 FROM dbo.dp_rate_changes WHERE product_id = ? AND status = 'PENDENTE'", (product_id,)).fetchone() is not None


def create_change(conn, product: dict, new_min: Decimal, new_max: Decimal, justification: str, user_id: int) -> int | None:
    """Devolve o id do pedido, ou None se já existir um pendente (índice único filtrado)."""
    try:
        cur = _q(
            conn,
            """INSERT INTO dbo.dp_rate_changes (product_id, old_min, old_max, new_min, new_max, justification, requested_by_id)
               OUTPUT INSERTED.id
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (product["id"], dec(product["min_rate"]), dec(product["max_rate"]), dec(new_min), dec(new_max), justification, user_id),
        )
        new_id = cur.fetchone()[0]
        conn.commit()
        return new_id
    except db.INTEGRITY_ERRORS:
        conn.rollback()
        return None


def _close_pending(conn, change_id: int, status: str, reviewer_id: int, comment: str | None) -> bool:
    """Fecha um pedido ainda PENDENTE, de forma atómica. False se entretanto já foi tratado."""
    cur = _q(
        conn,
        """UPDATE dbo.dp_rate_changes
              SET status = ?, reviewed_by_id = ?, reviewed_at = SYSUTCDATETIME(), review_comment = ?
            WHERE id = ? AND status = 'PENDENTE'""",
        (status, reviewer_id, comment, change_id),
    )
    return cur.rowcount == 1


def approve_change(conn, change: dict, reviewer_id: int, comment: str | None) -> bool:
    """Aprova e aplica as novas taxas ao produto, na MESMA transacção."""
    if not _close_pending(conn, change["id"], APROVADO, reviewer_id, comment):
        conn.rollback()
        return False
    _q(
        conn,
        "UPDATE dbo.dp_products SET min_rate = ?, max_rate = ?, updated_at = SYSUTCDATETIME() WHERE id = ?",
        (dec(change["new_min"]), dec(change["new_max"]), change["product_id"]),
    )
    conn.commit()
    return True


def reject_change(conn, change_id: int, reviewer_id: int, comment: str) -> bool:
    ok = _close_pending(conn, change_id, REJEITADO, reviewer_id, comment)
    conn.commit() if ok else conn.rollback()
    return ok


def cancel_change(conn, change_id: int, user_id: int) -> bool:
    ok = _close_pending(conn, change_id, CANCELADO, user_id, "Cancelado pelo autor")
    conn.commit() if ok else conn.rollback()
    return ok


# ------------------------------------------------------------------ histórico
_ESC = "ESCAPE '\\'"
_CI_AI = "COLLATE Latin1_General_CI_AI"  # ignora maiúsculas/minúsculas e acentos ("deposito" encontra "Depósito")


def _like(text: str) -> str:
    s = text.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_").replace("[", "\\[")
    return f"%{s}%"


def _history_where(q: str | None, produto: int | None, estado: str | None) -> tuple[str, list]:
    clauses: list[str] = []
    params: list = []
    if produto:
        clauses.append("c.product_id = ?")
        params.append(produto)
    if estado:
        clauses.append("c.status = ?")
        params.append(estado)
    if q and q.strip():
        cols = ["p.code", "p.name", "rq.full_name", "rq.username"]
        clauses.append("(" + " OR ".join(f"{c} {_CI_AI} LIKE ? {_ESC}" for c in cols) + ")")
        params += [_like(q)] * len(cols)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


def history(conn, q, produto, estado, page: int, page_size: int) -> tuple[int, list[dict]]:
    where, params = _history_where(q, produto, estado)
    total = _q(conn, f"SELECT COUNT(*) {_CHANGE_FROM}{where}", params).fetchone()[0]
    offset, size = (int(page) - 1) * int(page_size), int(page_size)  # inteiros validados: seguros para inline
    rows = _rows(
        _q(
            conn,
            f"SELECT {_CHANGE_COLS} {_CHANGE_FROM}{where} "
            f"ORDER BY c.requested_at DESC, c.id DESC OFFSET {offset} ROWS FETCH NEXT {size} ROWS ONLY",
            params,
        )
    )
    return total, rows


def history_all(conn, q, produto, estado, limit: int = 50000) -> list[dict]:
    where, params = _history_where(q, produto, estado)
    return _rows(
        _q(
            conn,
            f"SELECT {_CHANGE_COLS} {_CHANGE_FROM}{where} "
            f"ORDER BY c.requested_at DESC, c.id DESC OFFSET 0 ROWS FETCH NEXT {int(limit)} ROWS ONLY",
            params,
        )
    )


# ------------------------------------------------------------------ dados iniciais
def seed(conn) -> None:
    import logging

    log = logging.getLogger("dp_taxas")
    if _q(conn, "SELECT COUNT(*) FROM dbo.dp_users").fetchone()[0] == 0:
        users = [
            ("operador", "Operador Demo", ROLE_OPERADOR, os.getenv("SEED_OPERADOR_PASSWORD", "operador123")),
            ("aprovador", "Aprovador Demo", ROLE_APROVADOR, os.getenv("SEED_APROVADOR_PASSWORD", "aprovador123")),
        ]
        for username, full_name, role, pwd in users:
            _q(conn, "INSERT INTO dbo.dp_users (username, full_name, role, password_hash) VALUES (?, ?, ?, ?)",
               (username, full_name, role, hash_password(pwd)))
        log.warning("Utilizadores demo criados (operador / aprovador). Altere as passwords antes de ir para produção!")

    if os.getenv("SEED_DEMO_DATA", "1") == "1" and _q(conn, "SELECT COUNT(*) FROM dbo.dp_products").fetchone()[0] == 0:
        for code, name, lo, hi in DEMO_PRODUCTS:
            _q(conn, "INSERT INTO dbo.dp_products (code, name, min_rate, max_rate) VALUES (?, ?, ?, ?)",
               (code, name, Decimal(lo), Decimal(hi)))
    conn.commit()
