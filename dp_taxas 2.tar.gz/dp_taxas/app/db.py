"""Ligação ao SQL Server via pyodbc (DB-API 2.0, sem ORM).

Configuração por variáveis de ambiente — uma destas duas formas:

  1) DB_CONNECTION_STRING="DRIVER={ODBC Driver 18 for SQL Server};SERVER=srv;DATABASE=DPTaxas;Trusted_Connection=yes;..."

  2) DB_SERVER + DB_NAME  e  (DB_USER + DB_PASSWORD  ou  DB_TRUSTED=1 para autenticação Windows)
     opcionais: DB_DRIVER (por omissão "ODBC Driver 18 for SQL Server"), DB_TRUST_CERT=1
"""
import os
import re
from pathlib import Path

import pyodbc

SCHEMA_FILE = Path(__file__).resolve().parent.parent / "sql" / "schema.sql"

# Erros de violação de restrições (ex.: índice único do pedido pendente)
INTEGRITY_ERRORS: tuple = (pyodbc.IntegrityError,)


def _braced(value: str) -> str:
    return "{" + value.replace("}", "}}") + "}"


def build_conn_string() -> str:
    cs = os.getenv("DB_CONNECTION_STRING")
    if cs:
        return cs
    server, name = os.getenv("DB_SERVER"), os.getenv("DB_NAME")
    if not (server and name):
        raise RuntimeError(
            "Base de dados não configurada: defina DB_CONNECTION_STRING, ou DB_SERVER + DB_NAME "
            "(+ DB_USER/DB_PASSWORD ou DB_TRUSTED=1)."
        )
    driver = os.getenv("DB_DRIVER", "ODBC Driver 18 for SQL Server")
    parts = [f"DRIVER={_braced(driver)}", f"SERVER={server}", f"DATABASE={name}"]
    if os.getenv("DB_TRUSTED") == "1":
        parts.append("Trusted_Connection=yes")
    else:
        user, pwd = os.getenv("DB_USER"), os.getenv("DB_PASSWORD")
        if not (user and pwd):
            raise RuntimeError("Defina DB_USER e DB_PASSWORD, ou DB_TRUSTED=1 (autenticação Windows).")
        parts += [f"UID={_braced(user)}", f"PWD={_braced(pwd)}"]
    if os.getenv("DB_TRUST_CERT") == "1":
        parts.append("TrustServerCertificate=yes")
    return ";".join(parts)


def connect():
    """Nova ligação, sem autocommit (transacções explícitas). O pooling ODBC do pyodbc torna isto barato."""
    return pyodbc.connect(build_conn_string(), autocommit=False, timeout=10)


def get_db():
    """Dependência FastAPI: uma ligação por pedido; rollback em caso de erro."""
    conn = connect()
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_schema(conn) -> None:
    """Executa sql/schema.sql (lotes separados por 'GO'). Idempotente."""
    script = SCHEMA_FILE.read_text(encoding="utf-8")
    cur = conn.cursor()
    for batch in re.split(r"^\s*GO\s*$", script, flags=re.IGNORECASE | re.MULTILINE):
        if batch.strip():
            cur.execute(batch)
    conn.commit()
