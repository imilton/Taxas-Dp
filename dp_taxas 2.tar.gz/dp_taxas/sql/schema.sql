/* =====================================================================
   Gestão de Taxas de DP — esquema SQL Server (idempotente: pode correr várias vezes)
   Execute numa BD dedicada (ex.: DPTaxas) ou deixe a aplicação criá-lo no arranque
   (AUTO_CREATE_SCHEMA=1, por omissão). Em produção, o DBA pode correr este script
   e arrancar a aplicação com AUTO_CREATE_SCHEMA=0.
   ===================================================================== */

IF OBJECT_ID(N'dbo.dp_users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.dp_users (
        id            INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_dp_users PRIMARY KEY,
        username      NVARCHAR(60)  NOT NULL CONSTRAINT uq_dp_users_username UNIQUE,
        full_name     NVARCHAR(120) NOT NULL,
        role          VARCHAR(20)   NOT NULL CONSTRAINT ck_dp_users_role CHECK (role IN ('operador', 'aprovador')),
        password_hash VARCHAR(255)  NOT NULL,
        active        BIT           NOT NULL CONSTRAINT df_dp_users_active DEFAULT 1
    );
END
GO

IF OBJECT_ID(N'dbo.dp_products', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.dp_products (
        id         INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_dp_products PRIMARY KEY,
        code       VARCHAR(30)   NOT NULL CONSTRAINT uq_dp_products_code UNIQUE,
        name       NVARCHAR(160) NOT NULL,
        min_rate   DECIMAL(5,2)  NOT NULL,   -- percentagem, ex.: 11.75 = 11,75%
        max_rate   DECIMAL(5,2)  NOT NULL,
        updated_at DATETIME2(0)  NOT NULL CONSTRAINT df_dp_products_updated DEFAULT SYSUTCDATETIME(),
        CONSTRAINT ck_dp_products_rates CHECK (min_rate >= 0 AND max_rate <= 100 AND min_rate <= max_rate)
    );
END
GO

IF OBJECT_ID(N'dbo.dp_rate_changes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.dp_rate_changes (
        id              INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_dp_rate_changes PRIMARY KEY,
        product_id      INT           NOT NULL CONSTRAINT fk_dp_rc_product REFERENCES dbo.dp_products(id),
        old_min         DECIMAL(5,2)  NOT NULL,
        old_max         DECIMAL(5,2)  NOT NULL,
        new_min         DECIMAL(5,2)  NOT NULL,
        new_max         DECIMAL(5,2)  NOT NULL,
        status          VARCHAR(12)   NOT NULL CONSTRAINT df_dp_rc_status DEFAULT 'PENDENTE'
                        CONSTRAINT ck_dp_rc_status CHECK (status IN ('PENDENTE', 'APROVADO', 'REJEITADO', 'CANCELADO')),
        justification   NVARCHAR(500) NOT NULL,
        requested_by_id INT           NOT NULL CONSTRAINT fk_dp_rc_requested_by REFERENCES dbo.dp_users(id),
        requested_at    DATETIME2(0)  NOT NULL CONSTRAINT df_dp_rc_requested_at DEFAULT SYSUTCDATETIME(),
        reviewed_by_id  INT           NULL CONSTRAINT fk_dp_rc_reviewed_by REFERENCES dbo.dp_users(id),
        reviewed_at     DATETIME2(0)  NULL,
        review_comment  NVARCHAR(500) NULL,
        CONSTRAINT ck_dp_rc_rates CHECK (new_min >= 0 AND new_max <= 100 AND new_min <= new_max)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dp_rc_product' AND object_id = OBJECT_ID(N'dbo.dp_rate_changes'))
    CREATE INDEX ix_dp_rc_product ON dbo.dp_rate_changes (product_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dp_rc_requested_at' AND object_id = OBJECT_ID(N'dbo.dp_rate_changes'))
    CREATE INDEX ix_dp_rc_requested_at ON dbo.dp_rate_changes (requested_at DESC, id DESC);
GO

-- No máximo UM pedido pendente por produto (garantido pela BD, mesmo com pedidos simultâneos)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'uq_dp_rc_one_pending' AND object_id = OBJECT_ID(N'dbo.dp_rate_changes'))
    CREATE UNIQUE INDEX uq_dp_rc_one_pending ON dbo.dp_rate_changes (product_id) WHERE status = 'PENDENTE';
GO
