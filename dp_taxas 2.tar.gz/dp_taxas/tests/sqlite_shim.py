"""Adaptador SQLite com interface pyodbc, SÓ PARA TESTES.

Permite correr a API e a lógica de negócio sem SQL Server. Traduz apenas os 4 'dialectismos' T-SQL
usados em app/repo.py; o resto do SQL é padrão. Regista o T-SQL original executado (SQL_LOG) para
ser validado por um parser T-SQL (ver test_flow.py).
Não substitui um teste contra SQL Server real: use TEST_DB_CONNECTION_STRING (ver README).
"""
import re
import sqlite3
from datetime import datetime
from decimal import Decimal

sqlite3.register_adapter(Decimal, float)
sqlite3.register_converter("TIMESTAMP", lambda b: datetime.fromisoformat(b.decode()))

SQL_LOG: list[str] = []

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS dp_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, full_name TEXT NOT NULL,
    role TEXT NOT NULL, password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS dp_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
    min_rate NUMERIC NOT NULL, max_rate NUMERIC NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS dp_rate_changes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES dp_products(id),
    old_min NUMERIC NOT NULL, old_max NUMERIC NOT NULL, new_min NUMERIC NOT NULL, new_max NUMERIC NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDENTE', justification TEXT NOT NULL,
    requested_by_id INTEGER NOT NULL REFERENCES dp_users(id),
    requested_at TIMESTAMP NOT NULL DEFAULT (datetime('now')),
    reviewed_by_id INTEGER REFERENCES dp_users(id), reviewed_at TIMESTAMP, review_comment TEXT);
CREATE UNIQUE INDEX IF NOT EXISTS uq_dp_rc_one_pending ON dp_rate_changes (product_id) WHERE status = 'PENDENTE';
"""


def translate(sql: str) -> str:
    sql = sql.replace("dbo.", "")
    sql = sql.replace("SYSUTCDATETIME()", "datetime('now')")
    sql = re.sub(r"\s+COLLATE\s+\w+", "", sql)
    m = re.search(r"OUTPUT INSERTED\.(\w+)\s+", sql)
    if m:
        sql = sql.replace(m.group(0), "") + f" RETURNING {m.group(1)}"
    return re.sub(r"OFFSET (\d+) ROWS FETCH NEXT (\d+) ROWS ONLY", r"LIMIT \2 OFFSET \1", sql)


class Cursor:
    def __init__(self, cur):
        self._cur = cur

    def execute(self, sql, params=()):
        SQL_LOG.append(sql)
        self._cur.execute(translate(sql), tuple(params))
        return self

    @property
    def description(self):
        return self._cur.description

    @property
    def rowcount(self):
        return self._cur.rowcount

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()


class Conn:
    def __init__(self, path):
        self._c = sqlite3.connect(str(path), detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread=False)

    def cursor(self):
        return Cursor(self._c.cursor())

    def commit(self):
        self._c.commit()

    def rollback(self):
        self._c.rollback()

    def close(self):
        self._c.close()


def init_schema(conn: Conn) -> None:
    conn._c.executescript(SQLITE_SCHEMA)
