"""Fixture `client` com dois backends:

* por omissão: SQLite através do adaptador tests/sqlite_shim.py (rápido, sem servidor);
* TEST_DB_CONNECTION_STRING definida: corre os MESMOS testes contra um SQL Server real.
  Use uma BD de teste VAZIA e dedicada (os testes criam tabelas e dados de demonstração).
"""
import os
import sqlite3
import sys
import tempfile
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

try:
    import pyodbc  # noqa: F401
except ImportError:  # sem a biblioteca nativa unixODBC (ex.: ambientes de CI mínimos): stub só para importar a app
    _stub = types.ModuleType("pyodbc")
    _stub.IntegrityError = type("IntegrityError", (Exception,), {})
    sys.modules["pyodbc"] = _stub

import pytest
from fastapi.testclient import TestClient

REAL_DB = os.getenv("TEST_DB_CONNECTION_STRING")


@pytest.fixture(scope="module")
def client():
    from app import db
    from app.main import app

    mp = pytest.MonkeyPatch()
    if REAL_DB:
        mp.setenv("DB_CONNECTION_STRING", REAL_DB)
    else:
        import sqlite_shim

        path = Path(tempfile.mkdtemp()) / "test.db"
        mp.setattr(db, "connect", lambda: sqlite_shim.Conn(path))
        mp.setattr(db, "init_schema", sqlite_shim.init_schema)
        mp.setattr(db, "INTEGRITY_ERRORS", db.INTEGRITY_ERRORS + (sqlite3.IntegrityError,))
    with TestClient(app) as c:
        yield c
    mp.undo()
