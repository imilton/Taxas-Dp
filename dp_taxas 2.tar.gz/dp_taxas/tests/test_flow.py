import os
from decimal import Decimal

import pytest


def _login(client, user):
    client.post("/api/logout")
    r = client.post("/api/login", json={"username": user, "password": f"{user}123"})
    assert r.status_code == 200, r.text
    return r.json()


def test_auth_required(client):
    client.post("/api/logout")
    assert client.get("/api/produtos").status_code == 401
    assert client.get("/", follow_redirects=False).status_code == 307
    assert client.post("/api/login", json={"username": "operador", "password": "errada"}).status_code == 401


def test_full_flow(client):
    _login(client, "operador")
    prods = client.get("/api/produtos").json()
    p = prods[0]
    assert p["pending"] is None

    # validações
    bad = lambda **kw: client.post(f"/api/produtos/{p['id']}/alteracoes", json={"justification": "teste", **kw})
    assert bad(min_rate=10, max_rate=5).status_code == 422          # min > max
    assert bad(min_rate=-1, max_rate=5).status_code == 422          # negativa
    assert bad(min_rate=1, max_rate=101).status_code == 422         # > 100
    assert bad(min_rate=1.123, max_rate=5).status_code == 422       # 3 casas
    assert bad(min_rate=p["min_rate"], max_rate=p["max_rate"]).status_code == 422  # sem alteração

    # pedido válido
    r = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 6.5, "max_rate": 9.75, "justification": "Revisão ALCO"})
    assert r.status_code == 201, r.text
    change = r.json()
    assert change["status"] == "PENDENTE" and change["requested_by_username"] == "operador"

    # segundo pedido para o mesmo produto → 409
    r = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 7, "max_rate": 9.75, "justification": "outro"})
    assert r.status_code == 409

    # taxas ainda NÃO mudaram
    cur = next(x for x in client.get("/api/produtos").json() if x["id"] == p["id"])
    assert cur["min_rate"] == p["min_rate"] and cur["pending"]["id"] == change["id"]

    # operador não aprova
    assert client.post(f"/api/alteracoes/{change['id']}/aprovar", json={}).status_code == 403

    # aprovador aprova
    _login(client, "aprovador")
    assert client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 1, "max_rate": 2, "justification": "xxx"}).status_code == 403
    r = client.post(f"/api/alteracoes/{change['id']}/aprovar", json={"comment": "OK"})
    assert r.status_code == 200 and r.json()["status"] == "APROVADO" and r.json()["reviewed_by"] == "Aprovador Demo"
    assert client.post(f"/api/alteracoes/{change['id']}/aprovar", json={}).status_code == 409  # já tratado

    cur = next(x for x in client.get("/api/produtos").json() if x["id"] == p["id"])
    assert (cur["min_rate"], cur["max_rate"], cur["pending"]) == (6.5, 9.75, None)

    # histórico
    h = client.get("/api/historico", params={"estado": "APROVADO"}).json()
    assert h["total"] == 1 and h["items"][0]["new_max"] == 9.75 and h["items"][0]["requested_by"] == "Operador Demo"
    assert client.get("/api/historico", params={"q": "OPERADOR"}).json()["total"] == 1   # sem distinguir maiúsculas
    assert client.get("/api/historico", params={"q": "%"}).json()["total"] == 0          # '%' é literal, não wildcard
    assert client.get("/api/historico", params={"q": "DP001"}).json()["total"] == 1
    assert client.get("/api/historico", params={"estado": "XPTO"}).status_code == 422
    csv = client.get("/api/historico.csv")
    assert csv.status_code == 200 and "Revisão ALCO" in csv.text


def test_reject_and_cancel(client):
    _login(client, "operador")
    p = client.get("/api/produtos").json()[1]
    c1 = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 7.5, "max_rate": 10, "justification": "Teste rejeição"}).json()

    _login(client, "aprovador")
    assert client.post(f"/api/alteracoes/{c1['id']}/rejeitar", json={}).status_code == 422  # motivo obrigatório
    r = client.post(f"/api/alteracoes/{c1['id']}/rejeitar", json={"comment": "Fora da política"})
    assert r.status_code == 200 and r.json()["status"] == "REJEITADO"
    cur = next(x for x in client.get("/api/produtos").json() if x["id"] == p["id"])
    assert cur["min_rate"] == p["min_rate"]  # inalterada

    # cancelar: só o autor
    _login(client, "operador")
    c2 = client.post(f"/api/produtos/{p['id']}/alteracoes", json={"min_rate": 7.25, "max_rate": 10, "justification": "Teste cancelar"}).json()
    _login(client, "aprovador")
    assert client.post(f"/api/alteracoes/{c2['id']}/cancelar").status_code == 403
    _login(client, "operador")
    assert client.post(f"/api/alteracoes/{c2['id']}/cancelar").json()["status"] == "CANCELADO"


def test_unique_pending_enforced_by_db(client):
    """Mesmo contornando a verificação da app, a BD recusa um 2.º pedido pendente (índice único filtrado)."""
    from app import db, repo

    conn = db.connect()
    try:
        prod = repo.list_products(conn)[3]
        first = repo.create_change(conn, prod, Decimal("1.00"), Decimal("2.00"), "primeiro", 1)
        second = repo.create_change(conn, prod, Decimal("1.10"), Decimal("2.00"), "segundo", 1)
        assert first and second is None
    finally:
        conn.close()


def test_executed_sql_is_valid_tsql():
    """O T-SQL EXACTO que a app executou nos testes anteriores tem de ser sintaxe T-SQL válida."""
    if os.getenv("TEST_DB_CONNECTION_STRING"):
        pytest.skip("o servidor SQL Server real já validou o SQL")
    sqlglot = pytest.importorskip("sqlglot")
    from sqlglot import exp

    import sqlite_shim

    statements = {" ".join(s.split()) for s in sqlite_shim.SQL_LOG}
    assert len(statements) >= 15, "o log de SQL devia ter sido preenchido pelos testes anteriores"
    expected = {"SELECT": exp.Select, "INSERT": exp.Insert, "UPDATE": exp.Update}
    for s in sorted(statements):
        tree = sqlglot.parse_one(s, read="tsql")
        assert not isinstance(tree, exp.Command), f"sintaxe não reconhecida como T-SQL: {s}"
        kind = s.split()[0].upper()
        # verificação grosseira (o sqlglot é tolerante): tipo de instrução certo e FROM presente nos SELECT
        assert isinstance(tree, expected[kind]), f"instrução mal formada: {s}"
        assert kind != "SELECT" or tree.find(exp.From), f"SELECT sem FROM: {s}"
